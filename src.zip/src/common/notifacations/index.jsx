import React, { useState, useEffect, useRef } from "react";
import {
  Tabs,
  Typography,
  Button,
  Badge,
  Empty,
  Dropdown,
  notification,
} from "antd";
import { BiBell, BiCalendarEvent } from "react-icons/bi";
import { 
  FiUsers, 
  FiBriefcase, 
  FiCheckSquare, 
  FiCalendar, 
  FiUser,
  FiBell 
} from "react-icons/fi";
import {
  useGetAllNotificationsQuery,
  useMarkAsReadMutation,
  useClearAllNotificationsMutation,
} from "./services/notificationApi";
import "./notifications.scss";
import {
  selectCurrentUser,
  selectUserRole,
} from "../../auth/services/authSlice";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import moment from "moment";

// Define sections and their routes
const SECTIONS = {
  lead: {
    name: "Lead",
    route: "/dashboard/crm/leads",
    icon: <FiUsers style={{ marginRight: '8px' }} />,
  },
  deal: {
    name: "Deal",
    route: "/dashboard/crm/deals",
    icon: <FiBriefcase style={{ marginRight: '8px' }} />,
  },
  task: {
    name: "Task",
    route: "/dashboard/crm/tasks",
    icon: <FiCheckSquare style={{ marginRight: '8px' }} />,
  },
  meeting: {
    name: "Meeting",
    route: "/dashboard/crm/meetings",
    icon: <FiCalendar style={{ marginRight: '8px' }} />,
  },
  client: {
    name: "Client",
    route: "/dashboard/crm/clients",
    icon: <FiUser style={{ marginRight: '8px' }} />,
  },
};

const { Title } = Typography;
const NotificationsComponent = () => {
  const navigate = useNavigate();
  const loggedInUser = useSelector(selectCurrentUser);
  const userRole = useSelector(selectUserRole);
  const id = loggedInUser?.id;

  const isSuperAdmin = userRole === "super-admin";

  const {
    data: notificationsData,
    isLoading,
    error,
    refetch,
  } = useGetAllNotificationsQuery(id);


  const [markAsRead] = useMarkAsReadMutation();
  const [clearAll] = useClearAllNotificationsMutation();

  const [dropdownOpen, setDropdownOpen] = useState(false);
  const processedNotifications = useRef(new Set());
  const isFirstLoad = useRef(true);

  // Poll for new notifications every 5 seconds only if not super admin
  useEffect(() => {
    if (!isSuperAdmin) {
      const interval = setInterval(() => {
        refetch();
      }, 20000);
      return () => clearInterval(interval);
    }
  }, [refetch, isSuperAdmin]);
  // Filter notifications
  const notifications = notificationsData?.data || [];
  const unreadNotifications = notifications.filter((n) => {
    try {
      // Handle different formats of users field
      let assignedUsers = [];
      
      // If users is already an array (already parsed by backend)
      if (Array.isArray(n.users)) {
        assignedUsers = n.users;
      } 
      // If users is a string, try to parse it
      else if (typeof n.users === 'string') {
        try {
          const parsed = JSON.parse(n.users);
          assignedUsers = Array.isArray(parsed) ? parsed : [];
        } catch (parseError) {
          console.error("Error parsing users data for notification:", n.id, n.users);
          return false;
        }
      }
      // If users is a number or other type, skip this notification
      else {
        console.warn("Invalid users field type for notification:", n.id, typeof n.users, n.users);
        return false;
      }

      // Check if current user is in assigned users list
      const isAssignedUser = assignedUsers.includes(id);

      // Show notification if unread AND user is assigned
      return !n.read && isAssignedUser;
    } catch (error) {
      console.error("Error filtering notification:", n.id, error);
      return false;
    }
  });

  const normalNotifications = unreadNotifications.filter(
    (n) => n.notification_type === "normal"
  );
  const reminders = unreadNotifications.filter(
    (n) => n.notification_type === "reminder"
  );


  // Show notifications
  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case "high":
        return "#dc2626"; // red
      case "medium":
        return "#f59e0b"; // orange
      case "low":
        return "#10b981"; // green
      default:
        return "#7c3aed"; // default purple
    }
  };

  useEffect(() => {
    // Wait for the first load to finish fetching
    if (isLoading) return;

    // On first load, mark existing notifications as "processed" without showing popups
    if (isFirstLoad.current) {
      unreadNotifications.forEach((notif) => {
        processedNotifications.current.add(notif.id);
      });
      isFirstLoad.current = false;
      return;
    }

    // Show only NEW unread notifications
    unreadNotifications.forEach((notif) => {
      if (!processedNotifications.current.has(notif.id)) {
        const isReminder = notif.notification_type === "reminder";
        notification.info({
          message: (
            <span style={{ fontWeight: "bold", fontSize: "16px" }}>
              {notif.title || ""}
            </span>
          ),
          description: (
            <div>
              {notif.message && <div>{notif.message}</div>}
              <div style={{ marginTop: "4px", color: "#666" }}>
                {notif.date && (
                  <span style={{ fontWeight: 500 }}>
                    {new Date(notif.date).toLocaleDateString("en-GB")}
                  </span>
                )}
                {notif.time && (
                  <span style={{ fontWeight: 500 }}>
                    {" "}
                    {new Date(`2000-01-01 ${notif.time}`).toLocaleTimeString(
                      "en-US",
                      { hour: "numeric", minute: "numeric", hour12: true }
                    )}
                  </span>
                )}
              </div>
            </div>
          ),
          icon: isReminder ? (
            <BiCalendarEvent
              style={{ color: getPriorityColor(notif.priority) }}
            />
          ) : (
            <BiBell style={{ color: getPriorityColor(notif.priority) }} />
          ),
          placement: "topRight",
          duration: 4.5,
          key: notif.id,
          onClick: () => handleNotificationClick(notif),
          className: `notification-${notif.priority}`,
        });

        processedNotifications.current.add(notif.id);
      }
    });
  }, [unreadNotifications, isLoading]);

  const handleNotificationClick = (notification) => {
    // Handle redirection based on section and IDs
    if (notification.section) {
      if (notification.section === "lead") {
        // Navigate to lead overview with the lead ID
        navigate(`/dashboard/crm/leads/${notification.parent_id}`);
      } else if (notification.section === "deal") {
        // Navigate to deal detail with the deal ID
        navigate(`/dashboard/crm/deals/${notification.parent_id}`);
      } else if (notification.section === "task") {
        // Navigate to task detail with the task ID
        navigate(`/dashboard/crm/tasks`);
      } else if (notification.section === "task_calendar") {
        // Navigate to task calendar with the task ID
        navigate(`/dashboard/crm/task-calendar`);
      } else if (notification.section === "sales-invoice") {
        // Navigate to sales invoice with the invoice ID
        navigate(`/dashboard/crm/sales/invoice`);
      } else if (notification.section === "announcement") {
        // Navigate to announcement with the announcement ID
        navigate(`/dashboard/hrm/announcement`);
      } else if (notification.section === "products") {
        // Navigate to product details with the product ID
        if (notification.related_id) {
          navigate(`/dashboard/sales/product-services`, {
            state: { selectedProduct: notification.related_id },
          });
        } else {
          navigate(`/dashboard/sales/product-services`);
        }
      } else if (notification.section === "meeting") {
        // Navigate to meeting with the meeting ID
        navigate(`/dashboard/hrm/meeting`);
      } else if (notification.section === "calendar") {
        // Navigate to calendar with the calendar ID
        navigate(`/dashboard/hrm/calendar`);
      } else if (notification.section === "contact") {
        // Navigate to contact with the contact ID
        navigate(`/dashboard/crm/contact`);
      }
    }
  };

  const handleMarkAsRead = async (id, notification) => {
    try {
      await markAsRead(id);
      notification.close(id);
      // Refresh notifications after marking as read
      refetch();
    } catch (error) {
      console.error("Error marking notification as read:", error);
    }
  };

  const handleClearAll = async () => {
    try {
      await clearAll();
      setDropdownOpen(false);
    } catch (error) {
      console.error("Error clearing notifications:", error);
    }
  };

  // Group notifications by section
  const groupedNotifications = normalNotifications.reduce((acc, notif) => {
    const section = notif.section || "other";
    if (!acc[section]) {
      acc[section] = [];
    }
    acc[section].push(notif);
    return acc;
  }, {});

  const items = [
    {
      key: "1",
      label: (
        <span>
          Notifications
          <Badge
            count={normalNotifications.length}
            size="small"
            style={{ marginLeft: 8, backgroundColor: "#1890ff" }}
          />
        </span>
      ),
      children: (
        <div className="notifications-list">
          {normalNotifications.length > 0 ? (
            Object.entries(groupedNotifications).map(
              ([section, notifications]) => {
                const sectionConfig = SECTIONS[section] || {
                  name: section,
                  icon: <FiBell style={{ marginRight: '8px' }} />,
                };
                return (
                  <div key={section} className="notification-section">
                    <Typography.Title level={5} style={{ display: 'flex', alignItems: 'center' }}>
                      {sectionConfig.icon} {sectionConfig.name} Notifications
                    </Typography.Title>
                    {notifications.map((notification) => (
                      <div
                        key={notification.id}
                        className={`notification-item ${!notification.read ? "unread" : ""
                          }`}
                      >
                        <div
                          className="notification-content"
                          onClick={() => handleNotificationClick(notification)}
                        >
                          <div className="notification-icon-wrapper">
                            <BiBell className="notification-icon info" />
                          </div>
                          <div className="notification-details">
                            <Typography.Text
                              type="secondary"
                              className="message-text"
                            >
                              {notification.message}
                            </Typography.Text>
                            {notification.description && (
                              <div className="notification-details-list">
                                {notification.description
                                  .split(/[\n,]/)
                                  .filter(item => item.trim())
                                  .map((detail, index) => {
                                    const cleanDetail = detail.replace(/[\u{1F300}-\u{1F9FF}]|[\u{2700}-\u{27BF}]|•/gu, '').trim();
                                    if (!cleanDetail || cleanDetail.toLowerCase().includes('call details')) return null;

                                    const parts = cleanDetail.split(':');
                                    const label = parts[0]?.trim();
                                    let value = parts[1]?.trim();

                                    // Format time if the label is 'time'
                                    if (label?.toLowerCase() === 'time' && value) {
                                      try {
                                        // Handle HH:mm:ss format
                                        const timeParts = value.split(':');
                                        if (timeParts.length >= 2) {
                                          const hours = parseInt(timeParts[0]);
                                          const minutes = timeParts[1];
                                          const ampm = hours >= 12 ? 'PM' : 'AM';
                                          const hours12 = hours % 12 || 12;
                                          value = `${hours12}:${minutes} ${ampm}`;
                                        }
                                      } catch (e) {
                                        console.error("Error formatting time:", e);
                                      }
                                    }

                                    let valueClass = '';
                                    if (label?.toLowerCase() === 'priority') valueClass = `priority-${value?.toLowerCase()}`;
                                    if (label?.toLowerCase() === 'status') valueClass = `status-${value?.toLowerCase()}`;

                                    return (
                                      <div key={index} className="detail-row">
                                        <span className="detail-label">{label}</span>
                                        <span className={`detail-value ${valueClass}`}>{value}</span>
                                      </div>
                                    );
                                  })}
                              </div>
                            )}
                            {(notification.date || notification.time) && (
                              <div className="notification-time">
                                {notification.date && (
                                  <span>
                                    {new Date(
                                      notification.date
                                    ).toLocaleDateString("en-GB")}
                                  </span>
                                )}
                                {notification.time && (
                                  <span style={{ fontWeight: 500 }}>
                                    {" "}
                                    {new Date(
                                      `2000-01-01 ${notification.time}`
                                    ).toLocaleTimeString("en-US", {
                                      hour: "numeric",
                                      minute: "numeric",
                                      hour12: true,
                                    })}
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                        {!notification.read && (
                          <div className="notification-actions">
                            <Button
                              type="link"
                              size="small"
                              onClick={() =>
                                handleMarkAsRead(notification.id, notification)
                              }
                            >
                              Mark as Read
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                );
              }
            )
          ) : (
            <Empty description="No notifications" />
          )}
        </div>
      ),
    },
    {
      key: "2",
      label: (
        <span>
          Reminders
          <Badge
            count={reminders.length}
            size="small"
            style={{ marginLeft: 8, backgroundColor: "#1890ff" }}
          />
        </span>
      ),
      children: (
        <div className="notifications-list">
          {reminders.length > 0 ? (
            Object.entries(
              reminders.reduce((acc, reminder) => {
                const section = reminder.section || "other";
                if (!acc[section]) {
                  acc[section] = [];
                }
                acc[section].push(reminder);
                return acc;
              }, {})
            ).map(([section, sectionReminders]) => {
              const sectionConfig = SECTIONS[section] || {
                name: section,
                icon: <FiBell style={{ marginRight: '8px' }} />,
              };
              return (
                <div key={section} className="notification-section">
                  <Typography.Title level={5} style={{ display: 'flex', alignItems: 'center' }}>
                    {sectionConfig.icon} {sectionConfig.name} Reminders
                  </Typography.Title>
                  {sectionReminders.map((reminder) => (
                    <div
                      key={reminder.id}
                      className={`notification-item reminder-item ${!reminder.read ? "unread" : ""
                        }`}
                    >
                      <div
                        className="notification-content"
                        onClick={() => handleNotificationClick(reminder)}
                      >
                        <div className="notification-icon-wrapper">
                          <BiCalendarEvent className="notification-icon reminder" />
                        </div>
                        <div className="notification-details">
                          <Typography.Text
                            type="secondary"
                            className="message-text"
                          >
                            {reminder.message}
                          </Typography.Text>
                          {reminder.description && (
                            <div className="notification-description">
                              {reminder.description
                                .split("\n")
                                .filter(
                                  (line) =>
                                    line.includes("• Title:") ||
                                    line.includes("• Time:")
                                )
                                .map((line, index) => (
                                  <div key={index} className="description-item">
                                    {line.trim()}
                                  </div>
                                ))}
                            </div>
                          )}
                          <div className="reminder-time">
                            <span>
                              <BiCalendarEvent style={{ marginRight: "4px" }} />
                              {new Date(reminder.date).toLocaleDateString(
                                "en-GB"
                              )}
                            </span>
                            {reminder.time && (
                              <span>
                                {new Date(
                                  `2000-01-01 ${reminder.time}`
                                ).toLocaleTimeString("en-US", {
                                  hour: "numeric",
                                  minute: "numeric",
                                  hour12: true,
                                })}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      {!reminder.read && (
                        <div className="notification-actions">
                          <Button
                            type="link"
                            size="small"
                            onClick={() =>
                              handleMarkAsRead(reminder.id, reminder)
                            }
                          >
                            Mark as Read
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              );
            })
          ) : (
            <Empty description="No reminders" />
          )}
        </div>
      ),
    },
  ];
  const notificationPanel = (
    <div className="notifications-dropdown">
      <div className="notifications-header">
        <Title level={5}>Notifications</Title>
        {unreadNotifications.length > 0 && (
          <Button type="link" onClick={handleClearAll}>
            Clear all
          </Button>
        )}
      </div>
      <Tabs defaultActiveKey="1" items={items} className="notification-tabs" />
    </div>
  );
  const totalUnread = unreadNotifications.length;
  return (
    <Dropdown
      overlay={notificationPanel}
      trigger={["click"]}
      placement="bottomRight"
      overlayClassName="notification-dropdown-overlay"
      open={dropdownOpen}
      onOpenChange={(visible) => setDropdownOpen(visible)}
    >
      <Badge count={totalUnread} className="notification-badge" offset={[2, 2]}>
        <Button type="text" className="notification-button" loading={isLoading}>
          <BiBell className="notification-bell-icon" />
        </Button>
      </Badge>
    </Dropdown>
  );
};
export default NotificationsComponent;
