import React, { useMemo } from "react";
import { useSelector } from 'react-redux';
import { selectUserRole } from '../../../auth/services/authSlice';
import { useGetsubcriptionByIdQuery } from '../../../superadmin/module/SubscribedUser/services/SubscribedUserApi';
import moment from 'moment';
import {
  FiHome,
  FiSettings,
  FiUsers,
  FiShoppingBag,
  FiShoppingCart,
  FiTarget,
  FiFileText,
  FiCalendar,
  FiMail,
  FiMessageSquare,
  FiBriefcase,
  FiPhone,
  FiPackage,
  FiTrendingUp,
  FiTruck,
  FiCreditCard,
  FiCheckSquare,
  FiShield,
  FiMapPin,
  FiTag,
  FiClock,
  FiVideo,
  FiBell,
  FiFile,
  FiEdit3,
  FiBookOpen,
  FiGlobe,
  FiPercent,
  FiList,
  FiUserCheck,
  FiSliders,
  FiUser,
  FiDollarSign,
  FiGrid,
  FiHelpCircle,
  FiLink,
  FiZap,
  FiLayout,
  FiPlusSquare,
} from "react-icons/fi";
import BrandConfig from "../../../utils/brandName";
import CommonSidebar from "../../../components/Sidebar/Sidebar";
import useFeatureAccess from "../../../hooks/useFeatureAccess";
import LimitReachedModal from "../../../components/LimitReachedModal";
import { useState } from "react";

const Sidebar = ({ collapsed = false, onCollapsedChange = () => { }, loggedInUser, rolesData }) => {
  const { hasFeature, isSubscriptionExpired } = useFeatureAccess();
  const [upgradeModalVisible, setUpgradeModalVisible] = useState(false);
  const [lockedFeatureName, setLockedFeatureName] = useState('');

  const userRole = useSelector(selectUserRole);
  const isSuperAdminCompanyLogin = localStorage.getItem('isSuperAdminCompanyLogin') === 'true';

  const handleLockedClick = (item) => {
    setLockedFeatureName(item.title);
    setUpgradeModalVisible(true);
  };

  const userRoleData = userRole?.toLowerCase() !== 'client' ?
    rolesData?.message?.data?.find(role => role.id === loggedInUser?.role_id) : null;

  const userPermissions = useMemo(() => {
    if (!userRoleData?.permissions) return null;
    try {
      return typeof userRoleData.permissions === 'object' ? userRoleData.permissions : JSON.parse(userRoleData.permissions);
    } catch (e) { return null; }
  }, [userRoleData]);

  const checkPermission = (moduleKey) => {
    if (['settings', 'communication', 'support'].includes(moduleKey?.toLowerCase())) return true;
    if (userRole?.toLowerCase() === 'client') return true;
    if (!userPermissions) return false;
    const modulePermissions = userPermissions[moduleKey];
    return modulePermissions && modulePermissions.length > 0 && modulePermissions[0].permissions.includes('view');
  };

  const shouldShowMenuItem = (item) => {
    if (item.hidden) return false;
    if (isSubscriptionExpired) return ['Dashboard', 'Setting', 'Subscription'].includes(item.title);
    if (item.subItems && item.subItems.length === 0) return false;
    if (['Setting', 'Communication', 'Support', 'Integrations', 'Subscription'].includes(item.title)) return true;
    if (userRole?.toLowerCase() === 'client') return true;
    if (!item.permission) return true;
    if (item.subItems?.length > 0) return item.subItems.some(sub => !sub.permission || checkPermission(sub.permission));
    return checkPermission(item.permission);
  };

  const allMenuItems = [
    { title: "Dashboard", icon: <FiHome />, path: "/dashboard" },
    {
      title: "CRM",
      icon: <FiUsers />,
      isDropdown: true,
      permission: 'dashboards-crm',
      subItems: [
        { title: "Calendar", icon: <FiCalendar />, path: "/dashboard/crm/task-calendar", permission: "dashboards-TaskCalendar" },
        { title: "Leads", icon: <FiTarget />, path: "/dashboard/crm/leads", permission: "dashboards-lead" },
        { title: "Deals", icon: <FiShoppingBag />, path: "/dashboard/crm/deals", permission: "dashboards-deal" },
        { title: "Company", icon: <FiBriefcase />, path: "/dashboard/crm/company-account", permission: "dashboards-crm-company-account" },
        { title: "Contact", icon: <FiFileText />, path: "/dashboard/crm/contact", permission: "dashboards-crm-contact" },
        { title: "Custom Form", icon: <FiFileText />, path: "/dashboard/crm/custom-form", permission: "dashboards-custom-form" },
        { title: "Task", icon: <FiCheckSquare />, path: "/dashboard/crm/tasks", permission: "dashboards-task" },
        { 
          title: "Reports", 
          icon: <FiFileText />, 
          path: "/dashboard/crm/reports", 
          permission: "dashboards-reports",
          isLocked: !hasFeature('reports'),
          onLockedClick: handleLockedClick
        },
        { 
          title: "Analytics", 
          icon: <FiTrendingUp />, 
          path: "/dashboard/crm/analytics", 
          permission: "dashboards-analytics",
          isLocked: !hasFeature('reports'),
          onLockedClick: handleLockedClick
        },
        { title: "CRM System Setup", icon: <FiSettings />, path: "/dashboard/crm-setup", permission: "dashboards-systemsetup" }
      ].map(item => {
        const isLocked = item.isLocked !== undefined ? item.isLocked : false;
        return {
          ...item,
          isLocked,
          badge: isLocked ? "PRO" : item.badge
        };
      }).filter(item => !item.permission || checkPermission(item.permission))
    },
    {
      title: "Sales",
      icon: <FiShoppingCart />,
      isDropdown: true,
      permission: 'dashboards-sales',
      subItems: [
        { title: "Product & Services", icon: <FiPackage />, path: "/dashboard/sales/product-services", permission: "dashboards-sales-product-services" },
        { title: "Customer", icon: <FiUsers />, path: "/dashboard/sales/customer", permission: "dashboards-sales-customer" },
        { title: "Invoice", icon: <FiFileText />, path: "/dashboard/sales/invoice", permission: "dashboards-sales-invoice" },
        { title: "Credit Notes", icon: <FiFile />, path: "/dashboard/sales/credit-notes", permission: "dashboards-sales-credit-notes" },
        { 
          title: "Revenue", 
          icon: <FiTrendingUp />, 
          path: "/dashboard/sales/revenue", 
          permission: "dashboards-sales-revenue",
          isLocked: !hasFeature('reports'),
          onLockedClick: handleLockedClick
        },
        { 
          title: "Reports", 
          icon: <FiFileText />, 
          path: "/dashboard/crm/reports", 
          permission: "dashboards-reports",
          isLocked: !hasFeature('reports'),
          onLockedClick: handleLockedClick
        },
        { 
          title: "Analytics", 
          icon: <FiTrendingUp />, 
          path: "/dashboard/crm/analytics", 
          permission: "dashboards-analytics",
          isLocked: !hasFeature('reports'),
          onLockedClick: handleLockedClick
        }
      ].map(item => {
        const isLocked = item.isLocked !== undefined ? item.isLocked : false;
        return {
          ...item,
          isLocked,
          badge: isLocked ? "PRO" : item.badge
        };
      }).filter(item => !item.permission || checkPermission(item.permission))
    },
    {
      title: "Purchase",
      icon: <FiShoppingBag />,
      isDropdown: true,
      permission: 'dashboards-purchase',
      subItems: [
        { title: "Vendor", icon: <FiTruck />, path: "/dashboard/purchase/vendor", permission: "dashboards-purchase-vendor" },
        { title: "Billing", icon: <FiCreditCard />, path: "/dashboard/purchase/billing", permission: "dashboards-purchase-billing" },
        { title: "Debit Note", icon: <FiFileText />, path: "/dashboard/purchase/debit-note", permission: "dashboards-purchase-debit-note" }
      ].filter(item => !item.permission || checkPermission(item.permission))
    },
    {
      title: "User Management",
      icon: <FiUsers />,
      isDropdown: true,
      permission: 'extra-users',
      subItems: [
        { title: "Users", icon: <FiUser />, path: "/dashboard/user-management/users", permission: "extra-users-list" },
        { title: "Role", icon: <FiShield />, path: "/dashboard/hrm/role", permission: "extra-hrm-role" }
      ].filter(item => !item.permission || checkPermission(item.permission))
    },
    {
      title: "Communication",
      icon: <FiMessageSquare />,
      isDropdown: true,
      subItems: [
        { title: "Mail", icon: <FiMail />, path: "/dashboard/communication/mail", permission: "dashboards-communication" },
        { title: "Chat", icon: <FiMessageSquare />, path: "/dashboard/communication/chat", permission: "dashboards-communication" }
      ]
    },
    {
      title: "WhatsApp",
      icon: <FiPhone />,
      isDropdown: true,
      permission: "dashboards-communication",
      isLocked: !hasFeature('whatsapp'),
      onLockedClick: handleLockedClick,
      subItems: [
        { title: "WhatsApp Chat", icon: <FiMessageSquare />, path: "/dashboard/whatsapp-chat", permission: "dashboards-communication" },
        { title: "Message Templates", icon: <FiLayout />, path: "/dashboard/whatsapp/templates", permission: "dashboards-communication" },
        { title: "Broadcast", icon: <FiZap />, path: "/dashboard/whatsapp/broadcast", permission: "dashboards-communication" },
        { title: "Message log", icon: <FiList />, path: "/dashboard/whatsapp/messages", permission: "dashboards-communication" }
      ].map(sub => ({
        ...sub,
        isLocked: !hasFeature('whatsapp'),
        onLockedClick: handleLockedClick
      }))
    },
    {
      title: "Integrations",
      icon: <FiZap />,
      isDropdown: true,
      badge: "NEW",
      subItems: [
        { title: "Justdial", icon: <FiGlobe />, path: "/dashboard/integrations/justdial", permission: "dashboards-integrations-justdial" },
        { title: "Indiamart", icon: <FiShoppingCart />, path: "/dashboard/integrations/indiamart", permission: "dashboards-integrations-indiamart" },
        { title: "Google Meet", icon: <FiVideo />, path: "/dashboard/integrations/google-meet", permission: "dashboards-integrations-googlemeet" },
        { title: "Zoom Meet", icon: <FiVideo />, path: "/dashboard/integrations/zoom-meet", permission: "dashboards-integrations-zoommeet" },
        { title: "Meta Ads", icon: <FiTarget />, path: "/dashboard/integrations/meta-ads", permission: "dashboards-integrations-metaads" },
        { title: "WhatsApp API", icon: <FiPhone />, path: "/dashboard/settings/whatsapp", permission: "dashboards-integrations-whatsapp" },
        { title: "Website Webhooks", icon: <FiLink />, path: "/dashboard/integrations/webhooks", permission: "dashboards-integrations-webhooks" }
      ].filter(item => !item.permission || checkPermission(item.permission))
    },
    {
      title: "Workflows",
      icon: <FiZap />,
      path: "/dashboard/crm/automation",
      isLocked: !hasFeature('workflows'),
      onLockedClick: handleLockedClick,
    },
    {
      title: "HRM",
      icon: <FiUsers />,
      isDropdown: true,
      permission: 'extra-hrm',
      subItems: [
        { 
          title: "HRM Analytics", 
          icon: <FiTrendingUp />, 
          path: "/dashboard/hrm/analytics", 
          permission: "extra-hrm-analytics",
          isLocked: !hasFeature('reports'),
          onLockedClick: handleLockedClick
        },
        { title: "Employee", icon: <FiUsers />, path: "/dashboard/hrm/employee", permission: "extra-hrm-employee" },
        { title: "PayRoll", icon: <FiDollarSign />, path: "/dashboard/hrm/payroll", permission: "extra-hrm-payroll" },
        { title: "Branch", icon: <FiMapPin />, path: "/dashboard/hrm/branch", permission: "extra-hrm-branch" },
        { title: "Designation", icon: <FiTag />, path: "/dashboard/hrm/designation", permission: "extra-hrm-designation" },
        { title: "Department", icon: <FiGrid />, path: "/dashboard/hrm/department", permission: "extra-hrm-department" },
        { title: "Attendance", icon: <FiClock />, path: "/dashboard/hrm/attendance", permission: "extra-hrm-attendance-attendancelist" },
        { title: "Holiday", icon: <FiCalendar />, path: "/dashboard/hrm/holiday", permission: "extra-hrm-holiday" },
        { title: "Leave Management", icon: <FiCalendar />, path: "/dashboard/hrm/leave", permission: "extra-hrm-leave-leavelist" },
        { title: "Calendar", icon: <FiCalendar />, path: "/dashboard/hrm/calendar", permission: "extra-hrm-calendar" },
        { title: "Meeting", icon: <FiVideo />, path: "/dashboard/hrm/meeting", permission: "extra-hrm-meeting" },
        { title: "Announcement", icon: <FiBell />, path: "/dashboard/hrm/announcement", permission: "extra-hrm-announcement" },
        { title: "Document", icon: <FiFile />, path: "/dashboard/hrm/document", permission: "extra-hrm-document" },
        { title: "Training Setup", icon: <FiBookOpen />, path: "/dashboard/hrm/training", permission: "extra-hrm-trainingSetup" }
      ].map(item => {
        const isLocked = item.isLocked !== undefined ? item.isLocked : false;
        return {
          ...item,
          isLocked,
          badge: isLocked ? "PRO" : item.badge
        };
      }).filter(item => !item.permission || checkPermission(item.permission))
    },
    {
      title: "Job",
      icon: <FiBriefcase />,
      isDropdown: true,
      permission: "extra-hrm-jobs-joblist",
      subItems: [
        { title: "Jobs", icon: <FiBriefcase />, path: "/dashboard/job/jobs", permission: "extra-hrm-jobs-joblist" },
        { title: "Job Candidates", icon: <FiUsers />, path: "/dashboard/job/job-candidates", permission: "extra-hrm-jobs-jobcandidate" },
        { title: "Job On-Boarding", icon: <FiUserCheck />, path: "/dashboard/job/job-onboarding", permission: "extra-hrm-jobs-jobonbording" },
        { title: "Job Applications", icon: <FiFileText />, path: "/dashboard/job/job-applications", permission: "extra-hrm-jobs-jobapplication" },
        { title: "Offer Letters", icon: <FiFile />, path: "/dashboard/job/offer-letters", permission: "extra-hrm-jobs-jobofferletter" },
        { title: "Interviews", icon: <FiCalendar />, path: "/dashboard/job/interviews", permission: "extra-hrm-jobs-interview" }
      ].filter(item => !item.permission || checkPermission(item.permission))
    },
    {
      title: 'Setting',
      icon: <FiSettings />,
      isDropdown: true,
      subItems: [
        { title: 'General', icon: <FiSliders />, path: '/dashboard/settings/general' },
        { title: 'Payment', icon: <FiDollarSign />, path: '/dashboard/settings/payment' },
        { title: 'Countries', icon: <FiGlobe />, path: '/dashboard/settings/countries' },
        { title: 'Currencies', icon: <FiCreditCard />, path: '/dashboard/settings/currencies' },
        { title: 'Tax', icon: <FiPercent />, path: '/dashboard/settings/tax' },
        { title: 'ESignature', icon: <FiEdit3 />, path: '/dashboard/settings/esignature' }
      ].filter(sub => true)
    },
    {
      title: "Subscription",
      icon: <FiCreditCard />,
      path: "/dashboard/settings/plan",
      hidden: userRole?.toLowerCase() === 'employee'
    },
    {
      title: "Support",
      icon: <FiHelpCircle />,
      isDropdown: true,
      subItems: [
        { title: "Ticket", icon: <FiMessageSquare />, path: "/dashboard/support/ticket", permission: "dashboards-support-ticket" },
        { title: "Help Support", icon: <FiHelpCircle />, path: "/dashboard/support/help-support", permission: "dashboards-support-help" }
      ].filter(item => !item.permission || checkPermission(item.permission))
    }
  ];

  const filteredMenuItems = allMenuItems.filter(shouldShowMenuItem);

  return (
    <>
      <CommonSidebar 
        menuItems={filteredMenuItems}
        brandName={`${BrandConfig.appCapitalName} CRM`}
        profilePath="/dashboard/profile"
        collapsed={collapsed}
        onCollapsedChange={onCollapsedChange}
        isSidebarReady={true}
      />

      <LimitReachedModal
        visible={upgradeModalVisible}
        onCancel={() => setUpgradeModalVisible(false)}
        title={`${lockedFeatureName} Locked`}
        message={`The ${lockedFeatureName} feature is not included in your current plan. Upgrade now to unlock automated messaging and advanced features!`}
      />
    </>
  );
};

export default Sidebar;
