import React, { useMemo, useState, useRef, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  Card,
  Tabs,
  Breadcrumb,
  Button,
  Table,
  Tag,
  Typography,
  message,
  Space,
  Progress,
  Row,
  Col,
  Descriptions,
  Tooltip,
  Skeleton,
} from "antd";
import {
  FiArrowLeft,
  FiHome,
  FiUser,
  FiMail,
  FiPhone,
  FiMapPin,
  FiDollarSign,
  FiTarget,
  FiCalendar,
  FiActivity,
  FiFileText,
  FiUsers,
  FiClock,
  FiPaperclip,
  FiFolder,
  FiTrendingUp,
  FiTrendingDown,
  FiMinusCircle,
  FiPhoneCall,
  FiBox,
  FiBriefcase,
  FiGlobe,
  FiEdit2,
  FiCpu,
  FiLock,
} from "react-icons/fi";
import { FaWhatsapp, FaFacebook } from "react-icons/fa";
import { useGetLeadQuery, useGetLeadsQuery, useUpdateLeadMutation, useGetLeadAiSuggestionsQuery } from "../services/LeadApi";
import {
  useGetAllCurrenciesQuery,
  useGetAllCountriesQuery,
} from "../../../../module/settings/services/settingsApi";
import { useGetCompanyAccountsQuery } from "../../companyacoount/services/companyAccountApi";
import { useGetContactsQuery, useGetContactByIdQuery } from "../../contact/services/contactApi";
import CreateDeal from "../../deal/CreateDeal";
import EditLead from "../EditLead";
import { useGetPipelinesQuery } from "../../crmsystem/pipeline/services/pipelineApi";
import { useGetLeadStagesQuery } from "../../crmsystem/leadstage/services/leadStageApi";
import { useSelector } from "react-redux";
import { selectCurrentUser } from "../../../../../auth/services/authSlice.js";
import { selectStageOrder } from "../../crmsystem/leadstage/services/leadStageSlice";
import { useGetRolesQuery } from "../../../hrm/role/services/roleApi";
import dayjs from "dayjs";
import {
  useGetSourcesQuery,
  useGetStatusesQuery,
  useGetCategoriesQuery,
} from "../../crmsystem/souce/services/SourceApi.js";

import LeadActivity from "./activity";
import LeadNotes from "./notes";
import LeadFiles from "./files";
import LeadMembers from "./members";
import LeadFollowup from "./followup/index.jsx";
import LeadAI from "./ai";
import LeadWhatsapp from "./LeadWhatsapp.jsx";
import PageHeader from "../../../../../components/PageHeader";
import { useFeatureAccess } from "../../../../../hooks/useFeatureAccess";
import "./LeadOverview.scss";

const { Title, Text } = Typography;

const LeadStageProgress = ({
  stages = [],
  currentStageId,
  onStageClick,
  isWon,
  isLoading,
}) => {
  const [hasScroll, setHasScroll] = useState(false);
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  const containerRef = useRef(null);

  useEffect(() => {
    const checkScroll = () => {
      if (containerRef.current) {
        const hasHorizontalScroll = containerRef.current.scrollWidth > containerRef.current.clientWidth;
        setHasScroll(hasHorizontalScroll);
      }
    };

    const checkScreenSize = () => {
      setIsSmallScreen(window.innerWidth < 1000);
    };

    // Initial checks
    checkScroll();
    checkScreenSize();

    // Add listeners
    window.addEventListener('resize', checkScroll);
    window.addEventListener('resize', checkScreenSize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', checkScroll);
      window.removeEventListener('resize', checkScreenSize);
    };
  }, [stages]);

  if (!stages || stages.length === 0) {
    return null;
  }

  const currentStageIndex = stages.findIndex(
    (stage) => stage.id === currentStageId
  );

  const handleItemClick = (stageId, e) => {
    e.preventDefault();
    e.stopPropagation();

    if (isLoading || stageId === currentStageId || isWon || !onStageClick) {
      return;
    }
    onStageClick(stageId);
  };

  return (
    <div
      ref={containerRef}
      className={`lead-stage-progress-container ${isWon ? "converted" : ""} ${hasScroll ? "has-scroll" : ""}`}
      role="progressbar"
      aria-valuenow={currentStageIndex + 1}
      aria-valuemin={1}
      aria-valuemax={stages.length}
      style={{ 
        display: 'flex', 
        justifyContent: isSmallScreen ? 'flex-start' : 'flex-end',
        transition: 'justify-content 0.3s ease',
        overflowX: 'auto',
        scrollbarWidth: 'thin',
        msOverflowStyle: 'auto',
        WebkitOverflowScrolling: 'touch'
      }}
    >
      {stages.map((stage, index) => {
        const isCompleted = currentStageIndex > -1 && index < currentStageIndex;
        const isCurrent = stage.id === currentStageId;
        const isUpcoming =
          currentStageIndex === -1 || index > currentStageIndex;

        let statusClass = "";
        if (isCompleted) statusClass = "completed";
        else if (isCurrent) statusClass = "current";
        else if (isUpcoming) statusClass = "upcoming";

        return (
          <button
            key={stage.id}
            className={`stage-item ${statusClass} ${isLoading ? "loading" : ""} ${
              isWon ? "converted" : ""
            }`}
            onClick={(e) => handleItemClick(stage.id, e)}
            disabled={isLoading || isWon}
            type="button"
            aria-label={`Set stage to ${stage.stageName}`}
            aria-current={isCurrent ? "step" : undefined}
            style={{ 
              cursor: isLoading || isWon ? "not-allowed" : "pointer",
              flexShrink: 0
            }}
          >
            <span className="stage-name" title={stage.stageName}>
              {stage.stageName}
            </span>
            {isLoading && isCurrent && (
              <span className="loading-indicator">Updating...</span>
            )}
            {isWon && isCurrent && (
              <span className="converted-indicator">Converted</span>
            )}
          </button>
        );
      })}
      <style jsx="true">{`
        .lead-stage-progress-container {
          position: relative;
          display: flex;
          gap: 2px;
          width: 100%;
          margin: 20px 0;
          padding: 0 16px;
        }

        .lead-stage-progress-container.converted::after {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(255, 255, 255, 0.6);
          pointer-events: none;
          z-index: 1;
          border-radius: 8px;
        }

        .stage-item {
          flex: 1;
          position: relative;
          padding: 12px 16px;
          background: #f0f2f5;
          border: none;
          color: #8c8c8c;
          font-size: 14px;
          font-weight: 500;
          text-align: center;
          transition: all 0.3s ease;
          min-width: 120px;
        }

        .stage-item:first-child {
          border-top-left-radius: 8px;
          border-bottom-left-radius: 8px;
        }

        .stage-item:last-child {
          border-top-right-radius: 8px;
          border-bottom-right-radius: 8px;
        }

        .stage-item.completed {
          background: #52c41a;
          color: white;
        }

        .stage-item.current {
          background: #1890ff;
          color: white;
          font-weight: 600;
        }

        .stage-item.upcoming {
          background: #f0f2f5;
          color: #8c8c8c;
        }

        .stage-item.loading {
          opacity: 0.7;
        }

        .stage-item.converted {
          opacity: 0.8;
          cursor: not-allowed;
        }

        .loading-indicator {
          font-size: 12px;
          color: #ffffff;
          margin-left: 8px;
          opacity: 0.8;
        }

        .converted-indicator {
          font-size: 12px;
          color: #ffffff;
          margin-left: 8px;
          opacity: 0.8;
          font-style: italic;
        }

        .stage-item:not(:last-child)::after {
          content: "";
          position: absolute;
          right: -10px;
          top: 50%;
          transform: translateY(-50%);
          width: 20px;
          height: 2px;
          background: #e8e8e8;
          z-index: 0;
        }

        .stage-item.completed:not(:last-child)::after {
          background: #52c41a;
        }

        .stage-item:hover:not(.converted):not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
      `}</style>
    </div>
  );
};

const LeadOverviewContent = ({
  leadData: initialLeadData,
  pipelineStages,
  onStageUpdate,
  isUpdating,
  setIsEditModalOpen,
  pipelines,
  hasPermission
}) => { 

console.log("leaddata", initialLeadData)
  
  const loggedInUser = useSelector(selectCurrentUser);
  const { hasFeature, isLoading: isFeatureLoading } = useFeatureAccess();

  const [localLeadData, setLocalLeadData] = useState(initialLeadData);
  const { data: currencies = [] } = useGetAllCurrenciesQuery();
  const { data: sourcesData = [] } = useGetSourcesQuery(loggedInUser?.id);
  const { data: categoriesData = [] } = useGetCategoriesQuery(loggedInUser?.id);
  const { data: statusesData = [] } = useGetStatusesQuery(loggedInUser?.id);
  const { data: companyData = [] } = useGetCompanyAccountsQuery();
  
  const { data: associatedContact } = useGetContactByIdQuery(localLeadData?.contact_id, { 
    skip: !localLeadData?.contact_id 
  });

  const { data: countries = [] } = useGetAllCountriesQuery();

  const sources = sourcesData?.data || [];
  const categories = categoriesData?.data || [];
  const statuses = statusesData?.data || [];

  // Update local state when prop changes
  React.useEffect(() => {
    setLocalLeadData(initialLeadData);
  }, [initialLeadData]);


  const formatCurrencyValue = (value, currencyId) => {
    const currencyDetails = currencies?.find(
      (c) => c.id === currencyId || c.currencyCode === currencyId
    );
    if (!currencyDetails) return `${value}`;

    return new Intl.NumberFormat("en-US", {
      style: "decimal",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })
      .format(value)
      .replace(/^/, currencyDetails.currencyIcon + " ");
  };

  const getSourceName = (sourceId) => {
    const source = sources.find((s) => s.id === sourceId);
    return source?.name || "N/A";
  };

  const getCategoryName = (categoryId) => {
    const category = categories.find((c) => c.id === categoryId);
    return category?.name || "N/A";
  };

  const getStatusName = (statusId) => {
    const status = statuses.find((s) => s.id === statusId);
    return status?.name || "Pending";
  };

  const getPhoneWithCode = (phoneCode, phoneNumber) => {
    if (!phoneNumber || phoneNumber.toString().startsWith("META_")) return "-";
    const country = countries.find((c) => c.id === phoneCode);
    if (!country) return phoneNumber;
    
    const cleanCode = country.phoneCode.toString().replace(/\D/g, '');
    const cleanPhone = phoneNumber.toString().replace(/\D/g, '');
    
    if (cleanPhone.startsWith(cleanCode)) {
      return `${country.phoneCode} ${phoneNumber.toString().replace(/\D/g, '').slice(cleanCode.length)}`;
    }
    
    return `${country.phoneCode} ${phoneNumber}`;
  };

  const getPipelineName = (pipelineId) => {
    const pipeline = pipelines?.find((p) => p.id === pipelineId);
    return pipeline?.pipeline_name || pipeline?.name || "N/A";
  };

  const handleLocalStageUpdate = async (newStageId) => {
    // Optimistically update local state
    setLocalLeadData((prev) => ({
      ...prev,
      leadStage: newStageId,
    }));

    // Call parent handler
    onStageUpdate(newStageId);
  };

  return (
    <div className="overview-content">
      <div className="stage-progress-card">
        <LeadStageProgress
          stages={pipelineStages}
          currentStageId={localLeadData?.leadStage}
          onStageClick={handleLocalStageUpdate}
          isWon={localLeadData?.is_converted}
          isLoading={isUpdating}
        />
      </div>

      <Card className="info-card contact-card">
        <div className="profile-header">
          <div className="profile-main">
            <div className="company-avatars">
              {localLeadData?.company_id ? (
                <FiBriefcase size={24} />
              ) : localLeadData?.contact_id ? (
                <FiUser size={24} />
              ) : (
                <FiUser size={24} />
              )}
            </div>
            <div className="profile-info">
            <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
              <h2 className="company-names">{localLeadData?.leadTitle}</h2>
              {(!hasPermission || hasPermission('update')) && (
               <Button
                type="primary"
                icon={<FiEdit2 />}
                onClick={() => setIsEditModalOpen(true)}
                style={{
                  background: "linear-gradient(135deg, #1890ff 0%, #096dd9 100%)",
                  border: "none",
                  height: "44px",
                  padding: "0 24px",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  borderRadius: "10px",
                  fontWeight: "500",
                }}
              >
                Edit
              </Button>
              )}
            </div>
              <div className="contact-details">
                {localLeadData?.company_id &&
                  companyData?.data?.[0] &&
                  localLeadData?.contact_id &&
                  associatedContact ? (
                  <div className="combined-info">
                    <div className="info-section company-section">
                      <div className="icon-wrapper company">
                        <FiBriefcase className="icon" />
                      </div>
                      <span className="name">
                        {companyData.data[0].company_name}
                      </span>
                      {companyData.data[0].company_site && (
                        <a
                          href={companyData.data[0].company_site}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="website"
                        >
                          <div className="icon-wrapper website">
                            <FiGlobe className="icon" />
                          </div>
                          {companyData.data[0].company_site}
                        </a>
                      )}
                    </div>
                    <div className="separator-container" style={{display: 'flex', alignItems: 'center', gap: '4px'}}>
                    <span className="separator">•</span>
                    <div className="info-section contact-section">
                      <div className="icon-wrapper contact">
                        <FiUser className="icon" />
                      </div>
                      <span className="name">
                        {associatedContact?.first_name} {associatedContact?.last_name}
                      </span>
                    </div>
                    </div>
                  </div>
                ) : localLeadData?.company_id && companyData?.data?.[0] ? (
                  <div className=".company-infoo">
                    <div className="icon-wrapper company">
                      <FiBriefcase className="icon" />
                    </div>
                    <span className="name">
                      {companyData.data[0].company_name}
                    </span>
                    {companyData.data[0].company_site && (
                      <a
                        href={companyData.data[0].company_site}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="website"
                      >
                        <div className="icon-wrapper website">
                          <FiGlobe className="icon" />
                        </div>
                        {companyData.data[0].company_site}
                      </a>
                    )}
                  </div>
                ) : localLeadData?.contact_id && associatedContact ? (
                  <div className="contact-info">
                    <div className="icon-wrapper contact">
                      <FiUser className="icon" />
                    </div>
                    <span className="name">
                      {associatedContact?.first_name} {associatedContact?.last_name}
                    </span>
                  </div>
                ) : (
                  <div className="no-info">
                    <div className="icon-wrapper default">
                      <FiUser className="icon" />
                    </div>
                    <span>No Company or Contact Associated</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        {(localLeadData?.contact_id || localLeadData?.company_id) && (
          <div className="profile-stats" >
            <div className="stat-item">
              <div className="stat-content">
                <div className="stat-label"><FiMail style={{ marginRight: '8px', color: '#1890ff' }} /> Email Address</div>
                {localLeadData?.contact_id && associatedContact ? (
                  <a
                    href={`mailto:${associatedContact?.email}`}
                    className="stat-value"
                  >
                    {associatedContact?.email || "-"}
                  </a>
                ) : (
                  <span className="stat-value">-</span>
                )}
              </div>
            </div>
            <div className="stat-item">
              <div className="stat-content">
                <div className="stat-label"><FiPhone style={{ marginRight: '8px', color: '#1890ff' }} /> Phone Number</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  {localLeadData?.contact_id && associatedContact ? (
                    <a
                      href={`tel:${associatedContact?.phone}`}
                      className="stat-value"
                    >
                      {getPhoneWithCode(
                        associatedContact?.phone_code,
                        associatedContact?.phone
                      )}
                    </a>
                  ) : localLeadData?.company_id && companyData?.data?.[0] ? (
                    <a
                      href={`tel:${companyData.data[0].phone_number}`}
                      className="stat-value"
                    >
                      {getPhoneWithCode(
                        companyData.data[0].phone_code,
                        companyData.data[0].phone_number
                      )}
                    </a>
                  ) : (
                    <span className="stat-value">-</span>
                  )}
                  {(associatedContact?.phone || companyData?.data?.[0]?.phone_number) && (
                    <Tooltip title="Start WhatsApp Chat">
                      <Button 
                        type="text" 
                        icon={<FaWhatsapp style={{ color: '#25D366', fontSize: '16px' }} />} 
                        onClick={() => {
                          const phone = (associatedContact?.phone || companyData?.data?.[0]?.phone_number)?.replace(/\D/g, '');
                          window.location.href = `/dashboard/whatsapp-chat?phone=${phone}`;
                        }}
                        style={{ padding: 0, height: 'auto', display: 'flex', alignItems: 'center', minWidth: 'auto' }}
                      />
                    </Tooltip>
                  )}
                </div>
              </div>
            </div>
            <div className="stat-item">
              <div className="stat-content">
                <div className="stat-label"><FiMapPin style={{ marginRight: '8px', color: '#1890ff' }} /> Location</div>
                {localLeadData?.contact_id && associatedContact ? (
                  <Tooltip
                    title={`${associatedContact?.address || ""} ${associatedContact?.city ? `, ${associatedContact?.city}` : ""}${associatedContact?.state ? `, ${associatedContact?.state}` : ""}${associatedContact?.country ? `, ${associatedContact?.country}` : ""}`}
                  >
                    <div className="stat-value truncate">
                      {associatedContact?.address || "-"}
                      {associatedContact?.city && `, ${associatedContact?.city}`}
                      {associatedContact?.state && `, ${associatedContact?.state}`}
                      {associatedContact?.country && `, ${associatedContact?.country}`}
                    </div>
                  </Tooltip>
                ) : localLeadData?.company_id && companyData?.data?.[0] ? (
                  <Tooltip
                    title={`${companyData.data[0].billing_address || ""} ${companyData.data[0].billing_city
                      ? `, ${companyData.data[0].billing_city}`
                      : ""
                      }${companyData.data[0].billing_state
                        ? `, ${companyData.data[0].billing_state}`
                        : ""
                      }${companyData.data[0].billing_country
                        ? `, ${companyData.data[0].billing_country}`
                        : ""
                      }`}
                  >
                    <div className="stat-value truncate">
                      {companyData.data[0].billing_address || "-"}
                      {companyData.data[0].billing_city &&
                        `, ${companyData.data[0].billing_city}`}
                      {companyData.data[0].billing_state &&
                        `, ${companyData.data[0].billing_state}`}
                      {companyData.data[0].billing_country &&
                        `, ${companyData.data[0].billing_country}`}
                    </div>
                  </Tooltip>
                ) : (
                  <span className="stat-value">-</span>
                )}
              </div>
            </div>
          </div>
        )}

        <style jsx="true">{`
          .info-card {
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            transition: all 0.3s ease;
          }

          // .profile-header {
          //   padding: 24px;
          //   background: linear-gradient(135deg, #f6f8fd 0%, #f0f5ff 100%);
          //   border-bottom: 1px solid #e6e8f0;
          // }

          .profile-main {
            display: flex;
            align-items: center;
            gap: 20px;
          }

          .company-avatars {
            width: 56px;
            height: 56px;
            background: linear-gradient(135deg, #1890ff 0%, #096dd9 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            box-shadow: 0 4px 12px rgba(24, 144, 255, 0.15);
          }

          .profile-info {
            flex: 1;
          }

          .company-names {
            font-size: 24px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 8px;
            line-height: 1.3;
          }

          .contact-details {
            margin-top: 8px;
          }

          .combined-info {
            display: flex;
            align-items: center;
            gap: 12px;
            background: rgba(255, 255, 255, 0.9);
            padding: 8px 16px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            border: 1px solid #f0f0f0;
          }

          .info-section {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 4px 8px;
            border-radius: 8px;
            transition: all 0.3s ease;
          }

          .info-section:hover {
            background: rgba(0, 0, 0, 0.02);
          }

          .company-section .name {
            color: #1890ff;
            font-weight: 600;
          }

          .contact-section .name {
            color: #52c41a;
            font-weight: 600;
          }

          .separator {
            color: #d9d9d9;
            font-size: 20px;
            margin: 0 4px;
          }

          .website {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 4px 12px;
            border-radius: 6px;
            background: rgba(114, 46, 209, 0.1);
            color: #722ed1;
            text-decoration: none;
            transition: all 0.3s ease;
            margin-left: 8px;
          }

          .website:hover {
            background: rgba(114, 46, 209, 0.15);
            transform: translateY(-1px);
          }

          .company-infoo,
          .contact-info,
          .no-info {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.9);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            border: 1px solid #f0f0f0;
          }

          .icon-wrapper {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
          }

          .icon-wrapper.company {
            background: linear-gradient(135deg, #1890ff 0%, #096dd9 100%);
            box-shadow: 0 4px 12px rgba(24, 144, 255, 0.15);
          }

          .icon-wrapper.contact {
            background: linear-gradient(135deg, #52c41a 0%, #389e0d 100%);
            box-shadow: 0 4px 12px rgba(82, 196, 26, 0.15);
          }

          .icon-wrapper.website {
            background: linear-gradient(135deg, #722ed1 0%, #531dab 100%);
            box-shadow: 0 4px 12px rgba(114, 46, 209, 0.15);
            width: 24px;
            height: 24px;
          }

          .icon-wrapper.default {
            background: linear-gradient(135deg, #f5222d 0%, #cf1322 100%);
            box-shadow: 0 4px 12px rgba(245, 34, 45, 0.15);
          }

          .profile-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 24px;
            padding-top: 24px;
            background: transparent;
          }

          .stat-item {
            display: flex;
            flex-direction: column;
            gap: 4px;
            padding: 16px;
            background: #f8fafc;
            border-radius: 12px;
            transition: all 0.3s ease;
          }

          .stat-content {
            flex: 1;
          }

          .stat-label {
            font-size: 13px;
            color: #6b7280;
            margin-bottom: 4px;
            font-weight: 500;
          }

          .stat-value {
            font-size: 15px;
            color: #1f2937;
            font-weight: 500;
            word-break: break-word;
          }

          .stat-value a {
            color: #1890ff;
            text-decoration: none;
            transition: color 0.3s ease;
          }

          .stat-value a:hover {
            color: #096dd9;
            text-decoration: underline;
          }

          .stat-value.truncate {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 100%;
            display: block;
          }

          .stat-item:hover .stat-value.truncate {
            color: #1890ff;
            cursor: pointer;
          }

          @media (max-width: 768px) {
            .profile-stats {
              grid-template-columns: 1fr;
            }
          }
        `}</style>
      </Card>

      <Row gutter={[16, 16]} className="metrics-row">
        <Col xs={24} sm={12} md={12} lg={12} xl={6}>
          <Card className="metric-card lead-value-card">
            <div className="metric-icon">
              <FiDollarSign />
            </div>
            <div className="metric-content">
              <div className="metric-label">Lead Value</div>
              <div className="metric-value">
                {localLeadData?.leadValue
                  ? formatCurrencyValue(
                    localLeadData.leadValue,
                    localLeadData.currency
                  )
                  : "-"}
              </div>
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} md={12} lg={12} xl={6}>
          <Card
            className={`metric-card interest-level-card ${localLeadData?.interest_level || "medium"
              }`}
          >
            <div
              className={`metric-icon ${localLeadData?.interest_level || "medium"
                }`}
            >
              <FiTarget />
            </div>
            <div className="metric-content">
              <div
                className={`metric-label ${localLeadData?.interest_level || "medium"
                  }`}
              >
                Interest Level
              </div>
              <div className="metric-value">
                {localLeadData?.interest_level === "high" ? (
                  <span className="interest-text high">
                    <FiTrendingUp className="icon" /> High Interest
                  </span>
                ) : localLeadData?.interest_level === "low" ? (
                  <span className="interest-text low">
                    <FiTrendingDown className="icon" /> Low Interest
                  </span>
                ) : (
                  <span className="interest-text medium">
                    <FiMinusCircle className="icon" /> Medium Interest
                  </span>
                )}
              </div>
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} md={12} lg={12} xl={6}>
          <Card className="metric-card created-date-card">
            <div className="metric-icon">
              <FiCalendar className="icon" />
            </div>
            <div className="metric-content">
              <div className="metric-label">Created</div>
              <div className="metric-value">
                {localLeadData?.createdAt
                  ? new Date(localLeadData.createdAt).toLocaleDateString()
                  : "-"}
              </div>
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} md={12} lg={12} xl={6}>
          <Card className="metric-card members-card">
            <div className="metric-icon">
              <FiUsers />
            </div>
            <div className="metric-content">
              <div className="metric-label">Lead Members</div>
              <div className="metric-value">
                {(() => {
                  try {
                    if (!localLeadData?.lead_members) return "0";
                    
                    const parsedMembers = (() => {
                      try {
                        if (typeof localLeadData.lead_members === 'string') {
                          try {
                            return JSON.parse(localLeadData.lead_members);
                          } catch (parseError) {
                            console.error('Invalid JSON in lead_members (metrics):', parseError);
                            return { lead_members: [] };
                          }
                        } else {
                          return localLeadData.lead_members || { lead_members: [] };
                        }
                      } catch (error) {
                        console.error('Error processing lead members (metrics):', error);
                        return { lead_members: [] };
                      }
                    })();
                    
                    return parsedMembers?.lead_members?.length || "0";
                  } catch (error) {
                    console.error("Error displaying lead members count:", error);
                    return "0";
                  }
                })()}
              </div>
            </div>
          </Card>
        </Col>
      </Row>
      
      {localLeadData?.description && (
        <div className="lead-details-section meta-ads-section" style={{ marginTop: '24px' }}>
          {/* Customer Responses Section */}
          {localLeadData.description.includes('FORM SUBMISSION DETAILS:') && (
            <div style={{ marginBottom: '32px' }}>
              <Title level={5} style={{ fontSize: '13px', color: '#1877F2', textTransform: 'uppercase', letterSpacing: '0.15em', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <FaFacebook style={{ color: '#1877F2', fontSize: '18px' }} /> Meta Form Submission
              </Title>
              <Row gutter={[24, 24]}>
                {localLeadData.description
                  .split('--------------------------')[0]
                  .split('\n')
                  .filter(line => line.startsWith('•'))
                  .map((line, idx) => {
                    const [key, ...valParts] = line.replace('• ', '').split(':');
                    const value = valParts.join(':').trim();
                    return (
                      <Col xs={24} sm={12} md={12} lg={8} xl={6} key={`form-${idx}`}>
                        <div className="detail-card info-card">
                          <div className="detail-content" style={{ borderLeft: '4px solid #1877F2', background: 'linear-gradient(to right, #f0f7ff, #ffffff)' }}>
                            <div className="detail-icon" style={{ background: '#e7f3ff', color: '#1877F2' }}>
                              <FiFileText />
                            </div>
                            <div className="detail-info">
                              <div className="detail-label" style={{ color: '#1877F2', fontWeight: '700' }}>{key.trim().replace(/_/g, ' ')}</div>
                              <div className="detail-value" style={{ color: '#1c1e21' }}>{value}</div>
                            </div>
                            <div className="detail-indicator" style={{ background: '#1877F2' }} />
                          </div>
                        </div>
                      </Col>
                    );
                  })}
              </Row>
            </div>
          )}


          {/* Ad Tracking Section */}
          {localLeadData.description.includes('META ADS TRACKING:') && (
            <div>
              <Title level={5} style={{ fontSize: '13px', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.15em', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <FiTarget /> Meta Campaign Tracking
              </Title>
              <Row gutter={[24, 24]}>
                {localLeadData.description
                  .split('--------------------------')[1]
                  .split('\n')
                  .filter(line => line.startsWith('•'))
                  .map((line, idx) => {
                    const [key, ...valParts] = line.replace('• ', '').split(':');
                    const value = valParts.join(':').trim();
                    return (
                      <Col xs={24} sm={12} md={12} lg={8} xl={6} key={`meta-${idx}`}>
                        <div className="detail-card tracking-card">
                          <div className="detail-content">
                            <div className="detail-icon">
                              {key.includes('Campaign') ? <FiTrendingUp /> : key.includes('Form') ? <FiBox /> : <FiActivity />}
                            </div>
                            <div className="detail-info">
                              <div className="detail-label">{key.trim()}</div>
                              <div className="detail-value">{value}</div>
                            </div>
                            <div className="detail-indicator" />
                          </div>
                        </div>
                      </Col>



                    );
                  })}
              </Row>
            </div>
          )}

          {!localLeadData.description.includes('FORM SUBMISSION DETAILS:') && (
            <Row gutter={[24, 24]}>
              <Col span={24}>
                <div className="detail-card">
                  <div className="detail-content">
                    <div className="detail-icon"><FiFileText /></div>
                    <div className="detail-info">
                      <div className="detail-label">Description</div>
                      <div className="detail-value" style={{ whiteSpace: 'pre-wrap' }}>{localLeadData.description}</div>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          )}
        </div>
      )}


      <div className="lead-details-section" style={{ marginTop: '32px', borderTop: '1px solid #f1f5f9', paddingTop: '24px' }}>
        <Title level={5} style={{ fontSize: '14px', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <FiBox style={{ color: '#64748b' }} /> Basic Information
        </Title>
        <Row gutter={[24, 24]}>


          <Col xs={24} sm={12} md={12} lg={12} xl={6}>
            <div className="detail-card source-card">
              <div className="detail-content">
                <div className="detail-icon">
                  <FiPhone />
                </div>
                <div className="detail-info">
                  <div className="detail-label">Source</div>
                  <div className="detail-value">
                    {getSourceName(localLeadData?.source)}
                  </div>
                </div>
                <div className="detail-indicator" />
              </div>
            </div>
          </Col>
          <Col xs={24} sm={12} md={12} lg={12} xl={6}>
            <div className="detail-card category-card">
              <div className="detail-content">
                <div className="detail-icon">
                  <FiFolder />
                </div>
                <div className="detail-info">
                  <div className="detail-label">Category</div>
                  <div className="detail-value">
                    {getCategoryName(localLeadData?.category)}
                  </div>
                </div>
                <div className="detail-indicator" />
              </div>
            </div>
          </Col>

          <Col xs={24} sm={12} md={12} lg={12} xl={6}>
            <div className="detail-card status-card">
              <div className="detail-content">
                <div className="detail-icon">
                  <FiClock />
                </div>
                <div className="detail-info">
                  <div className="detail-label">Status</div>
                  <div className="detail-value">
                    {getStatusName(localLeadData?.status)}
                  </div>
                </div>
                <div className="detail-indicator" />
              </div>
            </div>
          </Col>
          <Col xs={24} sm={12} md={12} lg={12} xl={6}>
            <div className="detail-card updated-card">
              <div className="detail-content">
                <div className="detail-icon">
                  <FiUsers />
                </div>
                <div className="detail-info">
                  <div className="detail-label">Last Updated</div>
                  <div className="detail-value">
                    {localLeadData?.updatedAt
                      ? dayjs(localLeadData.updatedAt).format("MMM DD, YYYY")
                      : "-"}
                  </div>
                </div>
                <div className="detail-indicator" />
              </div>
            </div>
          </Col>
        </Row>
        <Row gutter={[24, 24]} style={{ marginTop: "24px" }}>
          <Col xs={24} sm={12} md={12} lg={12} xl={6}>
            <div className="detail-card source-card">
              <div className="detail-content">
                <div className="detail-icon">
                  <FiBox />
                </div>
                <div className="detail-info">
                  <div className="detail-label">Pipeline</div>
                  <div className="detail-value">
                    {getPipelineName(localLeadData?.pipeline)}
                  </div>
                </div>
                <div className="detail-indicator" />
              </div>
            </div>
          </Col>
          <Col xs={24} sm={12} md={12} lg={12} xl={6}>
            <div className="detail-card category-card">
              <div className="detail-content">
                <div className="detail-icon">
                  <FiUser />
                </div>
                <div className="detail-info">
                  <div className="detail-label">Created By</div>
                  <div className="detail-value" style={{ textTransform: 'capitalize' }}>
                    {localLeadData?.created_by || "-"}
                  </div>
                </div>
                <div className="detail-indicator" />
              </div>
            </div>
          </Col>
          <Col xs={24} sm={12} md={12} lg={12} xl={6}>
            <div className="detail-card status-card">
              <div className="detail-content">
                <div className="detail-icon">
                  <FiActivity />
                </div>
                <div className="detail-info">
                  <div className="detail-label">Created Via</div>
                  <div className="detail-value" style={{ textTransform: 'capitalize' }}>
                    {localLeadData?.created_via || "-"}
                  </div>
                </div>
                <div className="detail-indicator" />
              </div>
            </div>
          </Col>
          <Col xs={24} sm={12} md={12} lg={12} xl={6}>
            <div className="detail-card updated-card">
              <div className="detail-content">
                <div className="detail-icon">
                  <FiTrendingUp />
                </div>
                <div className="detail-info">
                  <div className="detail-label">Lead Score</div>
                  <div className="detail-value">
                    {isFeatureLoading ? (
                      <Skeleton.Button active size="small" style={{ width: 80, height: 20 }} />
                    ) : !hasFeature('ai_features') ? (
                      <span style={{ fontSize: '13px', fontWeight: '600', color: '#d48806', display: 'flex', alignItems: 'center' }}>
                        <FiLock style={{ marginRight: '4px', color: '#faad14' }} /> Locked 
                        <span style={{ fontSize: '8px', background: '#faad14', color: '#fff', padding: '1px 3px', borderRadius: '4px', marginLeft: '4px', fontWeight: 'bold' }}>PRO</span>
                      </span>
                    ) : (
                      localLeadData?.lead_score !== null && localLeadData?.lead_score !== undefined
                        ? localLeadData.lead_score
                        : "-"
                    )}
                  </div>
                </div>
                <div className="detail-indicator" />
              </div>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

const LeadOverview = () => {
  const { leadId } = useParams();
  const navigate = useNavigate();
  const { hasFeature, isLoading: isFeatureLoading } = useFeatureAccess();
  const { data: lead, isLoading: isLoadingLead } = useGetLeadQuery(leadId,{
    page: 1,
    pageSize: -1,
    search: "",
  });


  const { data: pipelines = [] } = useGetPipelinesQuery();
  const { data: allStagesData, isLoading: isLoadingStages } =
    useGetLeadStagesQuery();
  const [updateLead, { isLoading: isUpdatingLead }] = useUpdateLeadMutation();
  const currentUser = useSelector(selectCurrentUser);
  const { data: rolesData } = useGetRolesQuery(undefined, {
      skip: !currentUser || currentUser.roleName === 'super-admin' || currentUser.roleName === 'client'
  });
  const userRoleData = rolesData?.message?.data?.find(role => role.id === currentUser?.role_id);
  const userPermissions = React.useMemo(() => {
      if (!userRoleData?.permissions) return null;
      try {
          return typeof userRoleData.permissions === 'object' ? userRoleData.permissions : JSON.parse(userRoleData.permissions);
      } catch (e) { return null; }
  }, [userRoleData]);
  const hasPermission = React.useCallback((action) => {
      if (!currentUser) return false;
      if (currentUser.roleName === 'super-admin' || currentUser.roleName === 'client') return true;
      if (!userPermissions) return false;
      const perms = userPermissions['dashboards-lead'];
      if (!perms || perms.length === 0) return false;
      return (perms[0]?.permissions || []).includes(action);
  }, [currentUser, userPermissions]);
  
  const hasDealPermission = React.useCallback((action) => {
      if (!currentUser) return false;
      if (currentUser.roleName === 'super-admin' || currentUser.roleName === 'client') return true;
      if (!userPermissions) return false;
      const perms = userPermissions['dashboards-deal'];
      if (!perms || perms.length === 0) return false;
      return (perms[0]?.permissions || []).includes(action);
  }, [currentUser, userPermissions]);

  const [isCreateDealModalOpen, setIsCreateDealModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [localLeadData, setLocalLeadData] = useState(lead?.data);
  const savedStageOrder = useSelector(selectStageOrder);
  const { data: currencies = [] } = useGetAllCurrenciesQuery();
  const { data: countries = [] } = useGetAllCountriesQuery();
  const { data: sourcesData = [] } = useGetSourcesQuery(currentUser?.id);
  const { data: categoriesData = [] } = useGetCategoriesQuery(currentUser?.id);
  const { data: statusesData = [] } = useGetStatusesQuery(currentUser?.id);
  
  // TRIGGER BACKGROUND AI ANALYSIS: This ensures score is updated even if user doesn't click AI tab
  const { data: aiSuggestionsData, isFetching: isAiAnalyzing } = useGetLeadAiSuggestionsQuery(leadId, {
    skip: !leadId || !hasFeature('ai_features'),
  });

  const { data: associatedContact } = useGetContactByIdQuery(localLeadData?.contact_id, { 
    skip: !localLeadData?.contact_id 
  });


  // Update local state when lead data changes
  React.useEffect(() => {
    setLocalLeadData(lead?.data);
  }, [lead?.data]);

  const pipelineStages = useMemo(() => {
    if (!localLeadData?.pipeline || !allStagesData) return [];
    const stagesArray = Array.isArray(allStagesData)
      ? allStagesData
      : allStagesData.data || [];

    const filteredStages = stagesArray.filter(
      (stage) =>
        stage.pipeline === localLeadData.pipeline && stage.stageType === "lead"
    );

    if (savedStageOrder && savedStageOrder.length > 0) {
      const stageOrderMap = new Map(
        savedStageOrder.map((id, index) => [id, index])
      );

      return [...filteredStages].sort((a, b) => {
        const indexA = stageOrderMap.has(a.id)
          ? stageOrderMap.get(a.id)
          : Infinity;
        const indexB = stageOrderMap.has(b.id)
          ? stageOrderMap.get(b.id)
          : Infinity;

        if (indexA !== Infinity && indexB !== Infinity) {
          return indexA - indexB;
        }
        if (indexA !== Infinity && indexB === Infinity) {
          return -1;
        }
        if (indexA === Infinity && indexB !== Infinity) {
          return 1;
        }
        return (
          (a.order ?? 0) - (b.order ?? 0) ||
          a.stageName.localeCompare(b.stageName)
        );
      });
    } else {
      return filteredStages.sort(
        (a, b) =>
          (a.order ?? 0) - (b.order ?? 0) ||
          a.stageName.localeCompare(b.stageName)
      );
    }
  }, [localLeadData?.pipeline, allStagesData, savedStageOrder]);

  const formattedLeadData = useMemo(() => {
    if (!localLeadData) return null;
    
    // Parse lead_members safely
    const parsed = (() => {
      try {
        if (!localLeadData.lead_members) {
          return { lead_members: [] };
        }
        
        if (typeof localLeadData.lead_members === 'string') {
          try {
            return JSON.parse(localLeadData.lead_members);
          } catch (parseError) {
            console.error('Invalid JSON in lead_members:', parseError);
            return { lead_members: [] };
          }
        } else {
          return localLeadData.lead_members || { lead_members: [] };
        }
      } catch (error) {
        console.error('Error processing lead members:', error);
        return { lead_members: [] };
      }
    })();
    
    return {
      id: localLeadData.id,
      leadTitle: localLeadData.leadTitle,
      contact_id: localLeadData.contact_id,
      company_id: localLeadData.company_id,
      source: localLeadData.source,
      pipeline: localLeadData.pipeline,
      stage: localLeadData.leadStage,
      currency: localLeadData.currency,
      value: localLeadData.leadValue,
      category: localLeadData.category,
      status: localLeadData.status,
      interest_level: localLeadData.interest_level,
      lead_members: parsed?.lead_members || [],
      is_converted: localLeadData.is_converted,
    };
  }, [localLeadData]);

  const handleConvertToDeal = () => {
    if (localLeadData?.is_converted) {
      message.warning("This lead has already been converted to a deal");
      return;
    }
    setIsCreateDealModalOpen(true);
  };

  const handleStageUpdate = async (newStageId) => {
    if (!hasPermission || !hasPermission('update')) {
      message.warning("You do not have permission to update lead stages.");
      return;
    }

    if (newStageId === localLeadData?.leadStage) {
      return;
    }

    if (isUpdatingLead) return;

    // Optimistically update local state
    setLocalLeadData((prev) => ({
      ...prev,
      leadStage: newStageId,
    }));

    try {
      await updateLead({
        id: leadId,
        data: {
          leadStage: newStageId,
          updated_by: currentUser?.username || "system",
        },
      }).unwrap();
      message.success("Lead stage updated successfully!");
    } catch (error) {
      // Revert optimistic update on error
      setLocalLeadData((prev) => ({
        ...prev,
        leadStage: prev.leadStage,
      }));
      message.error(error?.data?.message || "Failed to update lead stage.");
    }
  };

  const items = useMemo(() => {
    const allItems = [
      {
        key: "overview",
        label: (
          <span>
            <FiFileText /> Overview
          </span>
        ),
        children: (
          <LeadOverviewContent
            leadData={localLeadData}
            pipelineStages={pipelineStages}
            onStageUpdate={handleStageUpdate}
            isUpdating={isUpdatingLead}
            setIsEditModalOpen={setIsEditModalOpen}
            pipelines={pipelines}
            hasPermission={hasPermission}
          />
        ),
      },
      {
        key: "members",
        label: (
          <span>
            <FiUsers /> Lead Members
          </span>
        ),
        children: <LeadMembers leadId={leadId} leadData={localLeadData} />,
      },
      {
        key: "activity",
        label: (
          <span>
            <FiActivity /> Activity
          </span>
        ),
        children: <LeadActivity leadId={leadId} />,
      },
      {
        key: "notes",
        label: (
          <span>
            <FiFileText /> Notes
          </span>
        ),
        children: <LeadNotes leadId={leadId} />,
      },
      {
        key: "files",
        label: (
          <span>
            <FiPaperclip /> Files
          </span>
        ),
        children: <LeadFiles leadId={leadId} />,
      },
      {
        key: "followup",
        label: (
          <span>
            <FiPhoneCall /> Follow-up
          </span>
        ),
        children: <LeadFollowup leadId={leadId} />,
      },
      {
        key: "ai",
        label: (
          <span style={{ display: 'flex', alignItems: 'center' }}>
            <FiCpu style={{ marginRight: '8px' }} /> 
            AI Assistant
            {isFeatureLoading ? null : !hasFeature('ai_features') ? (
              <span style={{ display: 'flex', alignItems: 'center', marginLeft: '4px' }}>
                <FiLock style={{ color: '#faad14', marginLeft: '4px' }} />
                <span style={{ fontSize: '9px', background: 'linear-gradient(135deg, #faad14 0%, #d48806 100%)', color: '#fff', padding: '2px 6px', borderRadius: '10px', marginLeft: '6px', fontWeight: 'bold', lineHeight: '1', boxShadow: '0 2px 4px rgba(250, 173, 20, 0.3)' }}>PRO</span>
              </span>
            ) : (
              <Tag 
                color="purple" 
                style={{ 
                  fontSize: '10px', 
                  marginLeft: '8px', 
                  borderRadius: '10px',
                  border: 'none',
                  fontWeight: '600',
                  padding: '0 8px',
                  lineHeight: '18px'
                }}
              >
                BETA
              </Tag>
            )}
          </span>
        ),
        children: isFeatureLoading ? (
          <div style={{ textAlign: 'center', padding: '60px 20px', background: '#f8fafc', borderRadius: '12px' }}>
            <Skeleton active paragraph={{ rows: 4 }} />
          </div>
        ) : hasFeature('ai_features') ? (
          <LeadAI leadId={leadId} leadData={localLeadData} />
        ) : (
          <div style={{ textAlign: 'center', padding: '60px 20px', background: '#f8fafc', borderRadius: '12px' }}>
            <div style={{ width: '80px', height: '80px', background: 'rgba(114, 46, 209, 0.1)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 24px' }}>
              <FiCpu size={40} style={{ color: '#722ed1' }} />
            </div>
            <h3 style={{ fontSize: '20px', fontWeight: '700', color: '#1e293b', marginBottom: '12px' }}>AI Assistant Locked</h3>
            <p style={{ color: '#64748b', maxWidth: '400px', margin: '0 auto 24px', fontSize: '15px' }}>
              Unlock AI-powered lead scoring, smart suggestions, and automated summaries by upgrading your plan.
            </p>
            <Button 
              type="primary" 
              size="large"
              onClick={() => navigate('/dashboard/settings/plan')}
              style={{ background: 'linear-gradient(135deg, #722ed1 0%, #531dab 100%)', border: 'none', height: '44px', padding: '0 32px', borderRadius: '8px', fontWeight: '600' }}
            >
              Upgrade Now
            </Button>
          </div>
        )
      },
      {
        key: "whatsapp",
        label: (
          <span>
            <FaWhatsapp style={{ color: '#25D366', marginRight: '6px' }} /> WhatsApp
            {isFeatureLoading ? null : !hasFeature('whatsapp') ? (
              <span style={{ display: 'inline-flex', alignItems: 'center', marginLeft: '4px' }}>
                <FiLock style={{ color: '#faad14', marginLeft: '4px' }} />
                <span style={{ fontSize: '9px', background: 'linear-gradient(135deg, #faad14 0%, #d48806 100%)', color: '#fff', padding: '2px 6px', borderRadius: '10px', marginLeft: '6px', fontWeight: 'bold', lineHeight: '1', boxShadow: '0 2px 4px rgba(250, 173, 20, 0.3)' }}>PRO</span>
              </span>
            ) : null}
          </span>
        ),
        children: isFeatureLoading ? (
          <div style={{ textAlign: 'center', padding: '60px 20px', background: '#f8fafc', borderRadius: '12px' }}>
            <Skeleton active paragraph={{ rows: 4 }} />
          </div>
        ) : hasFeature('whatsapp') ? (
          <LeadWhatsapp 
            leadId={leadId} 
            phone={associatedContact?.phone || localLeadData?.telephone} 
          />
        ) : (
          <div style={{ textAlign: 'center', padding: '60px 20px', background: '#f8fafc', borderRadius: '12px' }}>
            <div style={{ width: '80px', height: '80px', background: 'rgba(37, 211, 102, 0.1)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 24px' }}>
              <FaWhatsapp size={40} style={{ color: '#25D366' }} />
            </div>
            <h3 style={{ fontSize: '20px', fontWeight: '700', color: '#1e293b', marginBottom: '12px' }}>WhatsApp Messaging Locked</h3>
            <p style={{ color: '#64748b', maxWidth: '400px', margin: '0 auto 24px', fontSize: '15px' }}>
              Connect with your leads instantly on WhatsApp. Upgrade your plan to enable direct messaging and chat history.
            </p>
            <Button 
              type="primary" 
              size="large"
              onClick={() => navigate('/dashboard/settings/plan')}
              style={{ background: 'linear-gradient(135deg, #25D366 0%, #128C7E 100%)', border: 'none', height: '44px', padding: '0 32px', borderRadius: '8px', fontWeight: '600' }}
            >
              Unlock WhatsApp
            </Button>
          </div>
        )
      }
    ];

    return allItems;
  }, [localLeadData, pipelineStages, handleStageUpdate, isUpdatingLead, setIsEditModalOpen, associatedContact, pipelines, hasFeature]);

  const isLoading = isLoadingLead || isLoadingStages;

  return (
    <div className="project-page">
      <PageHeader
        title={
          <Space size="middle">
            {localLeadData?.leadTitle || "Lead Details"}
            {isFeatureLoading ? (
              <Skeleton.Button active size="small" style={{ width: 150, height: 26, borderRadius: 20 }} />
            ) : hasFeature('ai_features') ? (
              <Tooltip title={(!localLeadData?.lead_score) ? "AI Analysis pending or low interest" : `AI Lead Score: ${localLeadData.lead_score}%`}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  background: 'rgba(24, 144, 255, 0.05)',
                  padding: '2px 10px',
                  borderRadius: '20px',
                  border: '1px solid rgba(24, 144, 255, 0.2)',
                  gap: '8px',
                  boxShadow: '0 2px 4px rgba(0,0,0,0.02)'
                }}>
                  <div style={{ 
                    width: '8px', 
                    height: '8px', 
                    borderRadius: '50%', 
                    background: (localLeadData?.lead_score > 70) ? '#52c41a' : (localLeadData?.lead_score > 40) ? '#faad14' : '#ff4d4f',
                    boxShadow: `0 0 8px ${(localLeadData?.lead_score > 70) ? '#52c41a80' : (localLeadData?.lead_score > 40) ? '#faad1480' : '#ff4d4f80'}`
                  }} />
                  <span style={{ 
                    fontSize: '12px', 
                    fontWeight: '600', 
                    color: '#475569',
                    letterSpacing: '0.5px'
                  }}>
                    LEAD SCORE: <span style={{ color: '#1e293b', fontSize: '14px' }}>
                      {isAiAnalyzing 
                        ? "Analyzing..." 
                        : (aiSuggestionsData?.data?.score !== undefined && aiSuggestionsData?.data?.score !== null
                          ? aiSuggestionsData.data.score
                          : (localLeadData?.lead_score !== null && localLeadData?.lead_score !== undefined 
                            ? localLeadData.lead_score 
                            : "0"))}
                    </span>
                  </span>
                  <Tag 
                    color="blue" 
                    style={{ 
                      margin: 0, 
                      fontSize: '10px', 
                      borderRadius: '4px', 
                      border: 'none', 
                      background: 'rgba(24, 144, 255, 0.1)',
                      color: '#096dd9',
                      fontWeight: 'bold',
                      padding: '0 4px'
                    }}
                  >
                    AI
                  </Tag>
                </div>
              </Tooltip>
            ) : (
              <Tooltip title="Upgrade plan to unlock AI Lead Scoring">
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  background: 'rgba(250, 173, 20, 0.05)',
                  padding: '2px 10px',
                  borderRadius: '20px',
                  border: '1px solid #faad14',
                  gap: '8px',
                  cursor: 'help'
                }}>
                  <span style={{ fontSize: '12px', fontWeight: '600', color: '#d48806', display: 'flex', alignItems: 'center' }}>
                    AI SCORE LOCKED <FiLock style={{ marginLeft: '6px', fontSize: '14px' }} />
                    <span style={{ fontSize: '9px', background: '#faad14', color: '#fff', padding: '2px 4px', borderRadius: '4px', marginLeft: '6px', fontWeight: 'bold', lineHeight: '1' }}>PRO</span>
                  </span>
                </div>
              </Tooltip>
            )}
          </Space>
        }
        subtitle="Manage lead details and activities"
        breadcrumbItems={[
          {
            title: (
              <Link to="/dashboard">
                <FiHome style={{ marginRight: "4px" }} /> Home
              </Link>
            ),
          },
          {
            title: (
              <Link to="/dashboard/crm/leads">
                <FiUser style={{ marginRight: "4px" }} /> Leads
              </Link>
            ),
          },
          {
            title: <span style={{ color: '#1f2937', fontWeight: 600 }}>{localLeadData?.leadTitle || "Lead Details"}</span>,
          },
        ]}
        extraActions={
          <Space>
            {localLeadData?.is_converted && (
              <Tag color="success" style={{ margin: 0, fontSize: "14px" }}>
                Converted to Deal
              </Tag>
            )}
            <Button
              type="primary"
              icon={<FiArrowLeft />}
              onClick={() => navigate("/dashboard/crm/leads")}
              style={{
                background: "linear-gradient(135deg, #1890ff 0%, #096dd9 100%)",
                border: "none",
                height: "30px",
                padding: "0 16px",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                borderRadius: "8px",
                fontWeight: "500",
              }}
            >
              Back
            </Button>
            {(!localLeadData?.is_converted && (!hasDealPermission || hasDealPermission('create'))) && (
              <Button
                type="primary"
                onClick={handleConvertToDeal}
                style={{
                  background:
                    "linear-gradient(135deg, #52c41a 0%, #389e0d 100%)",
                  border: "none",
                  height: "30px",
                  padding: "0 16px",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  borderRadius: "8px",
                  fontWeight: "500",
                }}
              >
                Convert to Deal
              </Button>
            )}
          </Space>
        }
      />

      <div className="page-contentt">
        <div className="content-main">
          <Card loading={isLoading || isUpdatingLead}>
            <Tabs
              defaultActiveKey="overview"
              items={items}
              className="project-tabs"
              type="card"
              size="large"
              animated={{ inkBar: true, tabPane: true }}
            />
          </Card>
        </div>
      </div>

      <CreateDeal
        open={isCreateDealModalOpen}
        onCancel={() => setIsCreateDealModalOpen(false)}
        leadData={formattedLeadData}
        pipelines={pipelines}
      />

      {isEditModalOpen && (
        <EditLead
          open={isEditModalOpen}
          onCancel={() => setIsEditModalOpen(false)}
          initialValues={localLeadData}
          pipelines={pipelines}
          currencies={currencies}
          countries={countries}
          categoriesData={categoriesData}
          sourcesData={sourcesData}
          statusesData={statusesData}
        />
      )}
    </div>
  );
};

export default LeadOverview;
