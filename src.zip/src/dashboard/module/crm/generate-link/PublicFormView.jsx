import React, { useState, useEffect } from 'react';
import { Form, Input, Button, Card, Typography, Switch, InputNumber, message, Spin, Space, Select, Checkbox, Radio } from 'antd';
import { useParams, useNavigate } from 'react-router-dom';
import { useGetCustomFormByIdQuery, useSubmitFormResponseMutation } from './services/customFormApi';
import {
    FiUser,
    FiMail,
    FiPhone,
    FiFileText,
    FiCalendar,
    FiToggleRight,
    FiHash,
    FiMapPin,
    FiList,
    FiCheck,
    FiMessageSquare,
    FiBookmark,
    FiGrid,
    FiLayers,
    FiClock,
    FiAlertCircle
} from 'react-icons/fi';
import dayjs from 'dayjs';
import './PublicForm.scss';

const COUNTRY_CODES = [
    { code: '+91', country: 'IN', name: 'India' },
    { code: '+971', country: 'AE', name: 'UAE' },
    { code: '+1', country: 'US', name: 'USA' },
    { code: '+44', country: 'GB', name: 'UK' },
    { code: '+61', country: 'AU', name: 'Australia' },
    { code: '+1', country: 'CA', name: 'Canada' },
    { code: '+49', country: 'DE', name: 'Germany' },
    { code: '+33', country: 'FR', name: 'France' },
    { code: '+65', country: 'SG', name: 'Singapore' },
    { code: '+81', country: 'JP', name: 'Japan' },
    { code: '+86', country: 'CN', name: 'China' },
    { code: '+92', country: 'PK', name: 'Pakistan' },
    { code: '+880', country: 'BD', name: 'Bangladesh' },
    { code: '+94', country: 'LK', name: 'Sri Lanka' },
    { code: '+977', country: 'NP', name: 'Nepal' },
    { code: '+234', country: 'NG', name: 'Nigeria' },
    { code: '+254', country: 'KE', name: 'Kenya' },
    { code: '+27', country: 'ZA', name: 'South Africa' },
    { code: '+55', country: 'BR', name: 'Brazil' },
    { code: '+52', country: 'MX', name: 'Mexico' },
];

const { Title, Text, Paragraph } = Typography;
const { TextArea } = Input;
const { Option } = Select;

const FormExpired = () => (
    <div className="form-status-container">
        <div className="status-icon">
            <FiAlertCircle />
        </div>
        <Title level={2}>Form Has Expired</Title>
        <Text>This form is no longer accepting responses.</Text>
        <Text type="secondary">Please contact the organizer for more information.</Text>
    </div>
);

const FormCountdown = ({ startDate }) => {
    const [timeLeft, setTimeLeft] = useState(null);

    useEffect(() => {
        const calculateTimeLeft = () => {
            const now = dayjs();
            const start = dayjs(startDate);
            const diff = start.diff(now);

            if (diff <= 0) {
                return null;
            }

            const days = Math.floor(diff / (1000 * 60 * 60 * 24));
            const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((diff % (1000 * 60)) / 1000);

            return { days, hours, minutes, seconds };
        };

        const timer = setInterval(() => {
            setTimeLeft(calculateTimeLeft());
        }, 1000);

        setTimeLeft(calculateTimeLeft());

        return () => clearInterval(timer);
    }, [startDate]);

    if (!timeLeft) return null;

    return (
        <div className="form-status-container upcoming">
            <div className="status-icon">
                <FiClock />
            </div>
            <Title level={2}>Registration Opens Soon</Title>
            <div className="countdown-timer">
                <div className="countdown-item">
                    <span className="number">{timeLeft.days}</span>
                    <span className="label">Days</span>
                </div>
                <div className="countdown-item">
                    <span className="number">{timeLeft.hours}</span>
                    <span className="label">Hours</span>
                </div>
                <div className="countdown-item">
                    <span className="number">{timeLeft.minutes}</span>
                    <span className="label">Minutes</span>
                </div>
                <div className="countdown-item">
                    <span className="number">{timeLeft.seconds}</span>
                    <span className="label">Seconds</span>
                </div>
            </div>
            <Text>The registration will open on {dayjs(startDate).format('MMM DD, YYYY [at] hh:mm A')}</Text>
        </div>
    );
};

const FormSuccess = ({ onReset, title }) => (
    <div className="form-status-container success" style={{ padding: '40px 20px', textAlign: 'center' }}>
        <div 
            className="status-icon success-animation" 
            style={{ 
                background: '#f6ffed', 
                border: '1px solid #b7eb8f', 
                color: '#52c41a',
                width: '64px',
                height: '64px',
                fontSize: '32px',
                margin: '0 auto 20px'
            }}
        >
            <FiCheck />
        </div>
        <Title level={3} style={{ color: '#1f2937', marginBottom: '8px' }}>Response Submitted!</Title>
        <Paragraph style={{ fontSize: '14px', color: '#64748b', marginBottom: '24px' }}>
            Your details for <b>{title}</b> have been recorded.
        </Paragraph>
        <Button 
            type="primary" 
            onClick={onReset}
            style={{ 
                borderRadius: '8px', 
                height: '40px', 
                padding: '0 24px',
                background: '#52c41a',
                borderColor: '#52c41a'
            }}
        >
            Fill Again
        </Button>
    </div>
);

const PublicFormView = () => {
    const { formId } = useParams();
    const navigate = useNavigate();
    const [form] = Form.useForm();
    const { data: formData, isLoading, error } = useGetCustomFormByIdQuery(formId);
    const [submitFormResponse, { isLoading: isSubmitting }] = useSubmitFormResponseMutation();
    const [fields, setFields] = useState({});
    const [submitting, setSubmitting] = useState(false);
    const [checkboxStates, setCheckboxStates] = useState({});
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [phoneCodes, setPhoneCodes] = useState({});

    // Initialize checkbox states
    useEffect(() => {
        if (formData?.data) {
            try {
                const parsedFields = typeof formData.data.fields === 'string'
                    ? JSON.parse(formData.data.fields)
                    : formData.data.fields;
                setFields(parsedFields);

                // Initialize form values with defaults
                const defaultValues = {};
                const initialPhoneCodes = {};
                
                const initialCheckboxStates = {};
                const iterateFields = Array.isArray(parsedFields) ? parsedFields : Object.values(parsedFields);
                iterateFields.forEach((field) => {
                    const fieldKey = field.key || field.id;
                    if (field.default_value) {
                        defaultValues[fieldKey] = field.default_value;
                    }
                    if (field.type === 'phone') {
                        initialPhoneCodes[fieldKey] = '';
                    }
                    if (field.type === 'checkbox' && field.options) {
                        initialCheckboxStates[fieldKey] = {};
                        field.options.forEach(option => {
                            initialCheckboxStates[fieldKey][option] = false;
                        });
                    }
                });

                setCheckboxStates(initialCheckboxStates);
                setPhoneCodes(initialPhoneCodes);
                form.setFieldsValue({ ...initialCheckboxStates, ...defaultValues, ...initialPhoneCodes });
            } catch (error) {
                console.error('Error parsing fields:', error);
                message.error('Error loading form fields');
            }
        }
    }, [formData, form]);

    const handleCheckboxChange = (fieldKey, option, checked) => {
        setCheckboxStates(prev => {
            const newState = {
                ...prev,
                [fieldKey]: {
                    ...prev[fieldKey],
                    [option]: checked
                }
            };

            // Update form values
            form.setFieldsValue({
                [fieldKey]: newState[fieldKey]
            });

            return newState;
        });
    };

    const handleSubmit = async (values) => {
        try {
            setSubmitting(true);
            const submissionData = { ...values };

            // Ensure checkbox values are included
            Object.entries(checkboxStates).forEach(([fieldName, fieldValue]) => {
                submissionData[fieldName] = fieldValue;
            });

            // Handle phone numbers (combine code + number)
            Object.entries(phoneCodes).forEach(([fieldKey, code]) => {
                if (submissionData[fieldKey]) {
                    // Prepend code if not already present
                    const num = String(submissionData[fieldKey]).trim();
                    if (!num.startsWith('+')) {
                        submissionData[fieldKey] = `${code}${num}`;
                    }
                }
            });

            const response = await submitFormResponse({
                formId,
                data: { submission_data: submissionData }
            }).unwrap();

            if (response.success) {
                setIsSubmitted(true);
                form.resetFields();
                setCheckboxStates({});
            }
        } catch (error) {
            console.error('Form submission error:', error);
            message.error(error.data?.message || 'Failed to submit form');
        } finally {
            setSubmitting(false);
        }
    };

    // Add form validation debugging
    const onFieldsChange = (changedFields, allFields) => {
        console.log('Field changed:', changedFields);
        console.log('Current form values:', form.getFieldsValue());
    };

    if (isLoading) {
        return (
            <div className="public-form-loading">
                <Spin size="large" />
                <Text>Loading form...</Text>
            </div>
        );
    }

    if (error?.error?.code === 'BAD_REQUEST' && error?.error?.message === 'Form has expired') {
        return <FormExpired />;
    }

    if (error) {
        return (
            <div className="public-form-error">
                <Title level={3}>Unable to load form</Title>
                <Text type="secondary">Please try again later or contact support.</Text>
            </div>
        );
    }

    const now = dayjs();
    const startDate = dayjs(formData?.data?.start_date);
    const endDate = dayjs(formData?.data?.end_date);

    if (now.isBefore(startDate)) {
        return <FormCountdown startDate={startDate} />;
    }

    if (now.isAfter(endDate)) {
        return <FormExpired />;
    }

    const getFieldPrefix = (type) => {
        const iconProps = { className: 'field-icon' };
        switch (type) {
            case 'text':
            case 'name':
                return <FiUser {...iconProps} />;
            case 'message':
                return <FiMessageSquare {...iconProps} />;
            case 'email':
                return <FiMail {...iconProps} />;
            case 'phone':
                return <FiPhone {...iconProps} />;
            case 'select':
            case 'multiselect':
                return <FiGrid {...iconProps} />;
            case 'checkbox':
            case 'radio':
                return <FiLayers {...iconProps} />;
            case 'file':
                return <FiFileText {...iconProps} />;
            case 'boolean':
                return <FiToggleRight {...iconProps} />;
            default:
                return <FiBookmark {...iconProps} />;
        }
    };

    const renderField = (field) => {
        const fieldKey = field.key || field.id;
        const label = field.label || (typeof fieldKey === 'string' ? fieldKey.charAt(0).toUpperCase() + fieldKey.slice(1).replace(/([A-Z])/g, ' $1') : 'Field');

        const commonProps = {
            key: fieldKey,
            name: fieldKey,
            label: label,
            rules: [{ required: field.required, message: `Please enter ${label}` }],
            className: 'custom-form-item'
        };

        switch (field.type) {
            case 'text':
            case 'name':
                return (
                    <Form.Item {...commonProps}>
                        <Input
                            className="custom-input"
                            placeholder={`Enter ${label.toLowerCase()}`}
                            prefix={getFieldPrefix(field.type)}
                        />
                    </Form.Item>
                );
            case 'number':
                return (
                    <Form.Item {...commonProps}>
                        <InputNumber
                            className="custom-input"
                            style={{ width: '100%' }}
                            placeholder={`Enter ${label.toLowerCase()}`}
                            prefix={<FiHash className="field-icon" />}
                            min={field.validation?.min}
                            max={field.validation?.max}
                        />
                    </Form.Item>
                );
            case 'textarea':
                return (
                    <Form.Item {...commonProps}>
                        <Input.TextArea
                            className="custom-textarea"
                            rows={4}
                            placeholder={`Enter ${label.toLowerCase()}`}
                            prefix={<FiMessageSquare className="field-icon" />}
                        />
                    </Form.Item>
                );
            case 'email':
                return (
                    <Form.Item {...commonProps} rules={[...commonProps.rules, { type: 'email', message: 'Please enter a valid email' }]}>
                        <Input
                            className="custom-input"
                            placeholder="Enter email address"
                            prefix={getFieldPrefix('email')}
                        />
                    </Form.Item>
                );
            case 'phone':
                const selectBefore = (
                    <Select 
                        placeholder="Code" 
                        className="phone-code-select"
                        style={{ width: 90 }}
                        onChange={(val) => setPhoneCodes(prev => ({ ...prev, [fieldKey]: val }))}
                    >
                        {COUNTRY_CODES.map(c => (
                            <Option key={`${c.country}-${c.code}`} value={c.code}>
                                <span style={{ fontSize: '12px' }}>{c.code}</span>
                            </Option>
                        ))}
                    </Select>
                );
                return (
                    <Form.Item {...commonProps} rules={[...commonProps.rules, { pattern: /^\+?[\d\s\-\(\)\.]+$/, message: 'Please enter a valid phone number' }]}>
                        <Input
                            className="custom-input"
                            placeholder="Enter phone number"
                            addonBefore={selectBefore}
                            defaultValue={field.default_value}
                        />
                    </Form.Item>
                );
            case 'select':
                return (
                    <Form.Item {...commonProps}>
                        <Select
                            className="custom-select"
                            placeholder={`Select ${label.toLowerCase()}`}
                            suffixIcon={getFieldPrefix('select')}
                            options={field.options?.map(option => ({
                                label: option,
                                value: option
                            }))}
                        />
                    </Form.Item>
                );
            case 'multiselect':
                return (
                    <Form.Item {...commonProps}>
                        <Select
                            mode="multiple"
                            className="custom-select"
                            placeholder={`Select ${label.toLowerCase()}`}
                            suffixIcon={getFieldPrefix('multiselect')}
                            options={field.options?.map(option => ({
                                label: option,
                                value: option
                            }))}
                        />
                    </Form.Item>
                );
            case 'checkbox':
                return (
                    <Form.Item {...commonProps}>
                        <div className="checkbox-group-wrapper">
                            {getFieldPrefix('checkbox')}
                            <div className="custom-checkbox-group" style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                                {field.options?.map((option) => (
                                    <Checkbox
                                        key={option}
                                        checked={checkboxStates[fieldKey]?.[option] || false}
                                        onChange={(e) => handleCheckboxChange(fieldKey, option, e.target.checked)}
                                    >
                                        {option}
                                    </Checkbox>
                                ))}
                            </div>
                        </div>
                    </Form.Item>
                );
            case 'radio':
                return (
                    <Form.Item {...commonProps}>
                        <div className="radio-group-wrapper">
                            {getFieldPrefix('radio')}
                            <Radio.Group className="custom-radio-group">
                                {field.options?.map(option => (
                                    <Radio key={option} value={option}>{option}</Radio>
                                ))}
                            </Radio.Group>
                        </div>
                    </Form.Item>
                );
            case 'boolean':
                return (
                    <Form.Item {...commonProps} valuePropName="checked">
                        <Switch className="custom-switch" />
                    </Form.Item>
                );
            default:
                return null;
        }
    };

    return (
        <div className="public-form-container">
            <div className="form-header">
                <div className="header-content">
                    <div className="header-main">
                        <div className="header-text">
                            <Title level={2}>{formData?.data?.title}</Title>
                            <Paragraph>{formData?.data?.description}</Paragraph>
                        </div>
                    </div>


                </div>
            </div>

            <Card className="form-card">
                {isSubmitted ? (
                    <FormSuccess 
                        title={formData?.data?.title} 
                        onReset={() => setIsSubmitted(false)} 
                    />
                ) : (
                    <Form 
                        form={form}
                        layout="vertical"
                        onFinish={handleSubmit}
                        onFieldsChange={onFieldsChange}
                        className="custom-form"
                        validateTrigger={['onBlur', 'onChange']}
                    >
                        {(Array.isArray(fields) ? fields : Object.values(fields)).map((field) =>
                            renderField(field)
                        )}

                        <Form.Item className="form-submit">
                            <Button
                                type="primary"
                                htmlType="submit"
                                size="large"
                                loading={isSubmitting}
                            >
                                {isSubmitting ? 'Submitting...' : 'Submit Form'}
                            </Button>
                        </Form.Item>
                    </Form>
                )}
            </Card>
        </div>
    );
};

export default PublicFormView; 