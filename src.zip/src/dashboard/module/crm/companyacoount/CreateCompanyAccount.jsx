import React, { useState, useRef } from "react";
import {
  Modal,
  Form,
  Input,
  Button,
  Typography,
  Select,
  Row,
  Col,
  Divider,
  DatePicker,
  message,
  Switch,
  Popconfirm,
  Space,
} from "antd";
import {
  FiFileText,
  FiX,
  FiCalendar,
  FiTrash2,
  FiUser,
  FiMail,
  FiPhone,
  FiMapPin,
  FiTag,
  FiDollarSign,
  FiGlobe,
  FiBriefcase,
  FiUsers,
  FiCopy,
  FiChevronDown,
  
} from "react-icons/fi";
import { PlusOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import "./companyaccount.scss";
import { useCreateCompanyAccountMutation } from "./services/companyAccountApi";
import { useGetAllCountriesQuery } from '../../../module/settings/services/settingsApi';
import {
  useGetSourcesQuery,
  useDeleteSourceMutation,
  useGetCategoriesQuery,
  useDeleteCategoryMutation
} from "../crmsystem/souce/services/SourceApi";
import AddSourceModal from "../crmsystem/souce/AddSourceModal";
import AddCategoryModal from "../crmsystem/souce/AddCategoryModal";
import indianStatesAndCities from "../../../../utils/Indian_Cities_In_States_JSON.json";

const { Text } = Typography;
const { Option } = Select;
const { TextArea } = Input;

// Find the Indian phone code ID
const findIndianDefaults = (countries) => {
  const indiaCountry = countries?.find(c => c.countryCode === 'IN');
  return {
    defaultPhoneCode: indiaCountry?.id || 'K9GxyQ8rrXQycdLQNkGhczL',
  };
};

const CreateCompanyAccount = ({ open, onCancel, loggedInUser, companyAccountsResponse, onSuccess ,categoriesData}) => {
  const [form] = Form.useForm();
  const [createCompanyAccount, { isLoading }] = useCreateCompanyAccountMutation();
  const [copyBillingToShipping, setCopyBillingToShipping] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const selectedBillingState = Form.useWatch('billing_state', form);
  const selectedShippingState = Form.useWatch('shipping_state', form);

  const availableBillingCities = React.useMemo(() => {
    if (!selectedBillingState) return [];
    return indianStatesAndCities[selectedBillingState] || [];
  }, [selectedBillingState]);

  const availableShippingCities = React.useMemo(() => {
    if (!selectedShippingState) return [];
    return indianStatesAndCities[selectedShippingState] || [];
  }, [selectedShippingState]);

  // Get countries data
  const { data: countries = [] } = useGetAllCountriesQuery();
  const { defaultPhoneCode } = findIndianDefaults(countries);

  const { data: sourcesData } = useGetSourcesQuery(loggedInUser?.id);

  const sources = sourcesData?.data || [];

  const [deleteSource] = useDeleteSourceMutation();


  const [isAddCategoryVisible, setIsAddCategoryVisible] = useState(false);
  const [categoryDropdownOpen, setCategoryDropdownOpen] = useState(false);
  const categorySelectRef = React.useRef(null);
  const [deleteCategory] = useDeleteCategoryMutation();


  const [isAddSourceVisible, setIsAddSourceVisible] = useState(false);
  const [sourceDropdownOpen, setSourceDropdownOpen] = useState(false);
  const sourceSelectRef = useRef(null);

  // Find others category
  const othersCategory = categoriesData?.data?.find(cat => cat.name.toLowerCase() === "others") || null;

  // Add handlers for source and category
  const handleAddSourceClick = (e) => {
    e.stopPropagation();
    setSourceDropdownOpen(false);
    setIsAddSourceVisible(true);
  };

  // Handle add category click
  const handleAddCategoryClick = (e) => {
    e.stopPropagation();
    setIsAddCategoryVisible(true);
  };

  // Handle category deletion
  const handleDeleteCategory = async (categoryId) => {
    try {
      await deleteCategory(categoryId).unwrap();
      message.success("Category deleted successfully");
      // Clear the category field if the deleted category was selected
      if (form.getFieldValue('category') === categoryId) {
        form.setFieldValue('category', undefined);
      }
    } catch (error) {
      message.error(error.data?.message || "Failed to delete category");
    }
  };

   // Source handlers
   const handleDeleteSource = async (sourceId) => {
    try {
      await deleteSource(sourceId).unwrap();
      message.success("Source deleted successfully");
      // Clear the source field if the deleted source was selected
      if (form.getFieldValue("source") === sourceId) {
        form.setFieldValue("source", undefined);
      }
    } catch (error) {
      message.error(error.data?.message || "Failed to delete source");
    }
  };

  // Initialize form with default values
  React.useEffect(() => {
    form.setFieldsValue({
      phoneCode: defaultPhoneCode
    });
  }, [defaultPhoneCode, form]);

  const handleSubmit = async (values) => {
    try {
      // Get the selected country's phone code
      const selectedCountry = countries.find(c => c.id === values.phoneCode);
      const phoneNumber = values.phone_number ? values.phone_number.replace(/^0+/, '') : '';

      const companyData = {
        ...values,
        account_owner: loggedInUser?.id,
        phone_code: selectedCountry?.id || "",
        phone_number: phoneNumber,
        category: values.company_category || othersCategory?.id,
      }
      const response = await createCompanyAccount(companyData).unwrap();
      
      if (onSuccess) {
        onSuccess(response?.data || response);
      } else {
        message.success('Company created successfully');
        onCancel();
      }
      form.resetFields();
    } catch (error) {
      console.error("Submit Error:", error);
      message.error(error.data?.message || 'Failed to create contact');
    }
  };

  const handleCopyBillingToShipping = (checked) => {
    setCopyBillingToShipping(checked);
    if (checked) {
      const billingValues = form.getFieldsValue([
        'billing_address',
        'billing_city',
        'billing_state',
        'billing_pincode',
        'billing_country'
      ]);

      form.setFieldsValue({
        shipping_address: billingValues.billing_address,
        shipping_city: billingValues.billing_city,
        shipping_state: billingValues.billing_state,
        shipping_pincode: billingValues.billing_pincode,
        shipping_country: billingValues.billing_country
      });
    }
  };

  // Add these consistent styles from CreateLead
  const formItemStyle = {
    fontSize: "14px",
    fontWeight: "500",
  };

  const selectStyle = {
    width: "100%",
    height: "48px",
  };


  return (
    <Modal
      title={null}
      open={open}
      onCancel={onCancel}
      footer={null}
      width={800}
      destroyOnClose={true}
      centered
      closeIcon={null}
      className="pro-modal custom-modal"
      styles={{
        body: {
          padding: 0,
          borderRadius: "8px",
          overflow: "hidden",
        },
      }}
    >
      <div className="modal-header" style={{
        background: "linear-gradient(135deg, #1890ff 0%, #096dd9 100%)",
        padding: "24px",
        color: "#ffffff",
        position: "relative",
      }}>
        <Button
          type="text"
          onClick={onCancel}
          className="close-button"
        >
          <FiX />
        </Button>
        <div className="header-content">
          <div className="header-icon">
            <FiBriefcase />
          </div>
          <div>
            <h2>Create Company Account</h2>
            <Text>Fill in the information to create company account</Text>
          </div>
        </div>
      </div>

      <Form
        form={form}
        layout="vertical"
        onFinish={handleSubmit}
        requiredMark={false}
        className="company-account-form"
      >
        <div className="form-section">
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="account_owner"
                label={
                  <span className="form-label">
                    <FiUser />
                    Account Owner <span className="required">*</span>
                  </span>
                }
                rules={[{ required: true, message: "Please enter account owner" }]}
                initialValue={loggedInUser?.username}
              >
                <Input
                  placeholder="Enter account owner name"
                  size="large"
                  className="form-input"
                  disabled
                />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item
                name="company_name"
                label={
                  <span className="form-label">
                    <FiBriefcase />
                    Company Name <span className="required">*</span>
                  </span>
                }
                rules={[{ required: true, message: "Please enter company name" },
                  {
                    validator: (_, value) => {
                        if (!value) return Promise.resolve();
                        if (!/[a-z]/.test(value) && !/[A-Z]/.test(value)) {
                            return Promise.reject(
                                new Error('Company name must contain both uppercase or lowercase English letters')
                            );
                        }
                        return Promise.resolve();
                    }
                }
                ]}
              >
                <Input
                  placeholder="Enter company name"
                  size="large"
                  className="form-input"
                />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item
                name="email"
                label={
                  <span className="form-label">
                    <FiMail />
                    Email
                  </span>
                }
                rules={[
                  { type: "email", message: "Please enter valid email" }
                ]}
              >
                <Input
                  placeholder="Enter company email"
                  size="large"
                  className="form-input"
                />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item
                name="website"
                label={
                  <span className="form-label">
                    <FiGlobe />
                    Website
                  </span>
                }
              >
                <Input
                  placeholder="Enter company website"
                  size="large"
                  className="form-input"
                />
              </Form.Item>
            </Col>

            <Col span={24}>
              <Form.Item
                name="phoneGroup"
                label={
                  <span className="form-label">
                    <FiPhone />
                    Company Number
                  </span>
                }
              >
                <div style={{ display: 'flex', gap: '8px' }}>
                  <Form.Item
                    name="phoneCode"
                    noStyle
                    initialValue={defaultPhoneCode}
                  >
                    <Select
                      style={{ width: '120px', height: '48px' }}
                      className="phone-code-select-common"
                      suffixIcon={<FiChevronDown size={14} style={{ color: '#8c8c8c' }} />}
                      popupClassName="custom-select-dropdown"
                      showSearch
                      optionFilterProp="children"
                      filterOption={(input, option) =>
                        option?.children?.props?.children[0]?.props?.children?.toLowerCase().includes(input.toLowerCase())
                      }
                    >
                      {countries?.map((country) => (
                        <Option key={country.id} value={country.id}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <span style={{ fontSize: '14px' }}>{country.countryCode}</span>
                            <span style={{ fontSize: '14px' }}>+{country.phoneCode.replace('+', '')}</span>
                          </div>
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                  <Form.Item
                    name="phone_number"
                    noStyle
                    rules={[
                      { pattern: /^\d+$/, message: 'Please enter only numbers' },
                      { min: 10, message: 'Phone number must be at least 10 digits' },
                      { max: 15, message: 'Phone number cannot exceed 15 digits' },
                      {
                        validator: (_, value) => {
                          if (value && value.startsWith('0')) {
                            return Promise.reject('Phone number should not start with 0');
                          }
                          return Promise.resolve();
                        }
                      }
                    ]}
                    normalize={(value) => {
                      if (!value) return value;
                      // Remove any non-digit characters and leading zeros
                      return value.replace(/\D/g, '').replace(/^0+/, '');
                    }}
                  >
                    <Input
                      style={{ flex: 1, height: '48px' }}
                      placeholder="Enter company number"
                      className="form-input phone-number-input"
                      type="number"
                      onKeyDown={(e) => {
                        if (['e', 'E', '+', '-', '.'].includes(e.key)) {
                          e.preventDefault();
                        }
                      }}
                    />
                  </Form.Item>
                </div>
              </Form.Item>
            </Col>

            <Col span={24}>
              <Form.Item
                name="company_source"
                label={
                  <span className="form-label">
                    <FiTag />
                    Select Source 
                  </span>
                }
              >
                <Select
                  ref={sourceSelectRef}
                  open={sourceDropdownOpen}
                  onDropdownVisibleChange={setSourceDropdownOpen}
                  placeholder="Select source"
                  style={selectStyle}
                  popupClassName="custom-select-dropdown"
                  suffixIcon={<FiChevronDown size={14} style={{ color: '#8c8c8c' }} />}
                  dropdownRender={(menu) => (
                    <div onClick={(e) => e.stopPropagation()}>
                      {menu}
                      <Divider style={{ margin: "8px 0" }} />
                      <div
                        style={{
                          padding: "8px 12px",
                          display: "flex",
                          justifyContent: "center",
                        }}
                      >
                        <Button
                          type="primary"
                          icon={<PlusOutlined />}
                          onClick={handleAddSourceClick}
                          style={{
                            width: "100%",
                            background:
                              "linear-gradient(135deg, #1890ff 0%, #096dd9 100%)",
                            border: "none",
                            height: "40px",
                            borderRadius: "8px",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            gap: "8px",
                            boxShadow: "0 2px 8px rgba(24, 144, 255, 0.15)",
                            fontWeight: "500",
                          }}
                        >
                          Create Source
                        </Button>
                      </div>
                    </div>
                  )}
                >
                  {sources.map((source) => (
                    <Option key={source.id} value={source.id}>
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                          width: "100%",
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "8px",
                          }}
                        >
                          <div
                            style={{
                              width: "8px",
                              height: "8px",
                              borderRadius: "50%",
                              backgroundColor: source.color || "#1890ff",
                            }}
                          />
                          {source.name}
                        </div>
                        {form.getFieldValue("company_source") !== source.id && (
                          <Popconfirm
                            title="Delete Source"
                            description="Are you sure you want to delete this source?"
                            onConfirm={(e) => {
                              e?.stopPropagation?.();
                              handleDeleteSource(source.id);
                            }}
                            okText="Yes"
                            cancelText="No"
                            placement="left"
                          >
                            <Button
                              type="text"
                              icon={<FiTrash2 style={{ color: "#ff4d4f" }} />}
                              size="small"
                              onClick={(e) => e.stopPropagation()}
                              style={{
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                opacity: 0.8,
                                transition: "opacity 0.2s",
                                "&:hover": {
                                  opacity: 1,
                                  backgroundColor: "transparent",
                                },
                              }}
                            />
                          </Popconfirm>
                        )}
                      </div>
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>
        </div>

        <div style={{ padding: '0 24px', marginBottom: '24px', display: 'flex', justifyContent: 'flex-end' }}>
          <Button 
            type="link" 
            onClick={() => setShowAdvanced(!showAdvanced)}
            style={{ 
              padding: 0, 
              height: 'auto', 
              display: 'flex', 
              alignItems: 'center', 
              gap: '6px',
              color: '#1890ff',
              fontWeight: '500',
              fontSize: '14px'
            }}
          >
            {showAdvanced ? 'Show Less Details' : 'Show More Details (Advance)'}
            <FiChevronDown style={{ transform: showAdvanced ? 'rotate(180deg)' : 'none', transition: 'transform 0.3s' }} />
          </Button>
        </div>

        {showAdvanced && (
          <>
            <div className="form-section">
              <Text strong className="section-title">Company Details</Text>
              <Row gutter={16}>
                <Col span={12}>
                  <Form.Item
                    name="company_type"
                    label={
                      <span className="form-label">
                        <FiBriefcase />
                        Company Type
                      </span>
                    }
                  >
                    <Select
                      placeholder="Select company type"
                      style={selectStyle}
                      suffixIcon={<FiChevronDown size={14} style={{ color: '#8c8c8c' }} />}
                    >
                      <Option value="private">Private</Option>
                      <Option value="public">Public</Option>
                      <Option value="partnership">Partnership</Option>
                    </Select>
                  </Form.Item>
                </Col>

                <Col span={12}>
                  <Form.Item
                    name="company_category"
                    label={<span className="form-label"><FiTag /> Company Category</span>}
                  >
                    <Select
                      ref={categorySelectRef}
                      open={categoryDropdownOpen}
                      onDropdownVisibleChange={setCategoryDropdownOpen}
                      placeholder="Select category"
                      style={selectStyle}
                      popupClassName="custom-select-dropdown"
                      suffixIcon={<FiChevronDown size={14} style={{ color: '#8c8c8c' }} />}
                      showSearch
                      allowClear
                      filterOption={(input, option) =>
                        option.children.props.children[0].props.children[1].toLowerCase().includes(input.toLowerCase())
                      }
                      dropdownRender={(menu) => (
                        <div onClick={(e) => e.stopPropagation()}>
                          {menu}
                          <Divider style={{ margin: '8px 0' }} />
                          <div
                            style={{
                              padding: '8px 12px',
                              display: 'flex',
                              justifyContent: 'center'
                            }}
                          >
                            <Button
                              type="primary"
                              icon={<PlusOutlined />}
                              onClick={handleAddCategoryClick}
                              style={{
                                width: '100%',
                                background: 'linear-gradient(135deg, #1890ff 0%, #096dd9 100%)',
                                border: 'none',
                                height: '40px',
                                borderRadius: '8px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '8px',
                                boxShadow: '0 2px 8px rgba(24, 144, 255, 0.15)',
                                fontWeight: '500',
                              }}
                            >
                              Create Category
                            </Button>
                          </div>
                        </div>
                      )}
                    >
                      {categoriesData?.data?.map((category) => (
                        <Option key={category.id} value={category.id}>
                          <div style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            width: '100%'
                          }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                              <div
                                style={{
                                  width: '8px',
                                  height: '8px',
                                  borderRadius: '50%',
                                  backgroundColor: category.color || '#1890ff'
                                }}
                              />
                              {category.name}
                            </div>
                            {form.getFieldValue('company_category') !== category.id && (
                              <Popconfirm
                                title="Delete Category"
                                description="Are you sure you want to delete this category?"
                                onConfirm={(e) => {
                                  e?.stopPropagation?.();
                                  handleDeleteCategory(category.id);
                                }}
                                okText="Yes"
                                cancelText="No"
                                placement="left"
                              >
                                <Button
                                  type="text"
                                  icon={<FiTrash2 style={{ color: "#ff4d4f" }} />}
                                  size="small"
                                  onClick={(e) => e.stopPropagation()}
                                  style={{
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    opacity: 0.8,
                                    transition: "opacity 0.2s",
                                    "&:hover": {
                                      opacity: 1,
                                      backgroundColor: "transparent"
                                    }
                                  }}
                                />
                              </Popconfirm>
                            )}
                          </div>
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                </Col>

                <Col span={12}>
                  <Form.Item
                    name="company_revenue"
                    label={
                      <span className="form-label">
                        <FiDollarSign />
                        Company Revenue
                      </span>
                    }
                    style={{ marginTop: "22px" }}
                  >
                    <Input
                      placeholder="Enter company revenue"
                      size="large"
                      className="form-input"
                    />
                  </Form.Item>
                </Col>
              </Row>
            </div>

            <div className="form-section">
              <div className="section-header">
                <Text strong className="section-title">Billing Address</Text>
              </div>
              <Row gutter={16}>
                <Col span={24}>
                  <Form.Item
                    name="billing_address"
                    label={
                      <span className="form-label">
                        <FiMapPin />
                        Address
                      </span>
                    }
                  >
                    <TextArea
                      placeholder="Enter billing address"
                      rows={3}
                      className="form-textarea"
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={16}>
                <Col span={8}>
                  <Form.Item
                    name="billing_city"
                    label={
                      <span className="form-label">
                        <FiMapPin />
                        City
                      </span>
                    }
                    style={{ marginTop: "22px" }}
                  >
                    <Select
                      showSearch
                      placeholder="Select city"
                      size="large"
                      className="form-input"
                      disabled={!selectedBillingState}
                      filterOption={(input, option) =>
                        (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                      }
                      options={availableBillingCities.map(cityName => ({
                        label: cityName,
                        value: cityName
                      }))}
                    />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item
                    name="billing_state"
                    label={
                      <span className="form-label">
                        <FiMapPin />
                        State
                      </span>
                    }
                    style={{ marginTop: "22px" }}
                  >
                    <Select
                      showSearch
                      placeholder="Select state"
                      size="large"
                      className="form-input"
                      onChange={() => {
                        form.setFieldValue('billing_city', undefined);
                        form.setFieldValue('billing_country', 'India');
                      }}
                      filterOption={(input, option) =>
                        (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                      }
                      options={Object.keys(indianStatesAndCities).map(stateName => ({
                        label: stateName,
                        value: stateName
                      }))}
                    />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item
                    name="billing_pincode"
                    label={
                      <span className="form-label">
                        <FiMapPin />
                        Pincode
                      </span>
                    }
                    style={{ marginTop: "22px" }}
                  >
                    <Input
                      type="number"
                      placeholder="Enter pincode"
                      size="large"
                      className="form-input"
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={16}>
                <Col span={24}>
                  <Form.Item
                    name="billing_country"
                    label={
                      <span className="form-label">
                        <FiMapPin />
                        Country
                      </span>
                    }
                    style={{ marginTop: "22px" }}
                  >
                    <Input
                      placeholder="Enter country"
                      size="large"
                      className="form-input"
                    />
                  </Form.Item>
                </Col>
              </Row>
            </div>

            <div className="form-section">
              <div className="section-header">
                <Text strong className="section-title">Shipping Address</Text>
                <div className="copy-address-switch">
                  <Text>Same as Billing Address</Text>
                  <Switch
                    checked={copyBillingToShipping}
                    onChange={handleCopyBillingToShipping}
                    size="small"
                  />
                </div>
              </div>
              <Row gutter={16}>
                <Col span={24}>
                  <Form.Item
                    name="shipping_address"
                    label={
                      <span className="form-label">
                        <FiMapPin />
                        Address
                      </span>
                    }
                  >
                    <TextArea
                      placeholder="Enter shipping address"
                      rows={3}
                      className="form-textarea"
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={16}>
                <Col span={8}>
                  <Form.Item
                    name="shipping_city"
                    label={
                      <span className="form-label">
                        <FiMapPin />
                        City
                      </span>
                    }
                    style={{ marginTop: "22px" }}
                  >
                    <Select
                      showSearch
                      placeholder="Select city"
                      size="large"
                      className="form-input"
                      disabled={!selectedShippingState}
                      filterOption={(input, option) =>
                        (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                      }
                      options={availableShippingCities.map(cityName => ({
                        label: cityName,
                        value: cityName
                      }))}
                    />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item
                    name="shipping_state"
                    label={
                      <span className="form-label">
                        <FiMapPin />
                        State
                      </span>
                    }
                    style={{ marginTop: "22px" }}
                  >
                    <Select
                      showSearch
                      placeholder="Select state"
                      size="large"
                      className="form-input"
                      onChange={() => {
                        form.setFieldValue('shipping_city', undefined);
                        form.setFieldValue('shipping_country', 'India');
                      }}
                      filterOption={(input, option) =>
                        (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                      }
                      options={Object.keys(indianStatesAndCities).map(stateName => ({
                        label: stateName,
                        value: stateName
                      }))}
                    />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item
                    name="shipping_pincode"
                    label={
                      <span className="form-label">
                        <FiMapPin />
                        Pincode
                      </span>
                    }
                    style={{ marginTop: "22px" }}
                  >
                    <Input
                      type="number"
                      placeholder="Enter pincode"
                      size="large"
                      className="form-input"
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={16}>
                <Col span={24}>
                  <Form.Item
                    name="shipping_country"
                    label={
                      <span className="form-label">
                        <FiMapPin />
                        Country
                      </span>
                    }
                    style={{ marginTop: "22px" }}
                  >
                    <Input
                      placeholder="Enter country"
                      size="large"
                      className="form-input"
                    />
                  </Form.Item>
                </Col>
              </Row>
            </div>
          </>
        )}

        <Divider className="form-divider" />

        <div className="form-footer">
          <Button
            size="large"
            onClick={onCancel}
            className="cancel-button"
          >
            Cancel
          </Button>
          <Button
            size="large"
            type="primary"
            htmlType="submit"
            loading={isLoading}
            className="submit-button"
          >
            Create Company
          </Button>
        </div>
      </Form>

      <AddSourceModal
        isOpen={isAddSourceVisible}
        onClose={(success) => {
          setIsAddSourceVisible(false);
          if (success) {
            setSourceDropdownOpen(true);
          }
        }}
      />

      <AddCategoryModal
        isOpen={isAddCategoryVisible}
        onClose={(success) => {
          setIsAddCategoryVisible(false);
          if (success) {
            setCategoryDropdownOpen(true);
          }
        }}
      />

      <style jsx="true" global="true">{`
        .company-account-form {
          padding: 24px;

          .form-label {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #374151;
            font-size: 14px;
            margin-bottom: 8px;

            svg {
              color: #1890ff;
              font-size: 16px;
            }

            .required {
              color: #ff4d4f;
            }
          }

          .ant-select:not(.ant-select-customize-input) .ant-select-selector {
            background-color: #f9fafb !important;
            border: 1px solid #e5e7eb !important;
            border-radius: 10px !important;
            min-height: 48px !important;
            padding: 0 16px !important;
            display: flex !important;
            align-items: center !important;
          }

          .ant-select-single .ant-select-selector .ant-select-selection-item,
          .ant-select-single .ant-select-selector .ant-select-selection-placeholder,
          .ant-select-single .ant-select-selector .ant-select-selection-search,
          .ant-select-single .ant-select-selector .ant-select-selection-search-input {
            line-height: 48px !important;
            height: 48px !important;
            transition: all 0.3s !important;
            display: flex !important;
            align-items: center !important;
            padding: 0 !important;
          }

          .phone-code-select-common {
            .ant-select-selector {
              border-top-right-radius: 0 !important;
              border-bottom-right-radius: 0 !important;
              padding: 0 8px !important;
              height: 48px !important;
              display: flex !important;
              align-items: center !important;
            }
          }

          .phone-input-group {
            display: flex !important;
            
            .form-input {
              border-top-left-radius: 0 !important;
              border-bottom-left-radius: 0 !important;
            }
          }

          .ant-select-dropdown {
            padding: 8px !important;
            border-radius: 10px !important;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08) !important;

            .ant-select-item {
              padding: 8px 12px !important;
              border-radius: 6px !important;
              min-height: 32px !important;
              display: flex !important;
              align-items: center !important;
              color: #1f2937 !important;

              &-option-selected {
                background-color: #E6F4FF !important;
                font-weight: 500 !important;
                color: #1890ff !important;
              }

              &-option-active {
                background-color: #F3F4F6 !important;
              }
            }

            .ant-select-item-option-content {
              font-size: 14px !important;
            }

            .ant-select-item-empty {
              color: #9CA3AF !important;
            }
          }

          /* Unified Phone Input Styles */
          .ant-space-compact {
            background-color: #f9fafb;
            border-radius: 10px;
            border: 1px solid #e5e7eb;
            transition: all 0.3s ease;
            overflow: hidden;

            &:hover, &:focus-within {
              border-color: #1890ff;
              box-shadow: 0 0 0 2px rgba(24, 144, 255, 0.1);
            }

            .phone-code-select-common .ant-select-selector,
            .phone-number-input {
              border: none !important;
              box-shadow: none !important;
              background-color: transparent !important;
            }

            .phone-code-select-common {
              border-right: 1px solid #e5e7eb !important;
              border-radius: 0 !important;
            }
          }
        }
      `}</style>
    </Modal>
  );
};

export default CreateCompanyAccount;
